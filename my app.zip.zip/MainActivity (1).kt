package com.example

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.outlined.History
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.QrCodeScanner
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavDestination.Companion.hasRoute
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.toRoute
import com.example.ui.components.MobilePeLogoMark
import com.example.ui.navigation.BillsRoute
import com.example.ui.navigation.CheckBalanceRoute
import com.example.ui.navigation.HistoryRoute
import com.example.ui.navigation.HomeRoute
import com.example.ui.navigation.NotificationsRoute
import com.example.ui.navigation.ProfileRoute
import com.example.ui.navigation.ScannerRoute
import com.example.ui.navigation.TransferRoute
import com.example.ui.screens.AuthScreen
import com.example.ui.screens.BillsScreen
import com.example.ui.screens.CheckBalanceScreen
import com.example.ui.screens.HistoryScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.NotificationsScreen
import com.example.ui.screens.PaymentFlowScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.ScannerScreen
import com.example.ui.theme.MobilePeTheme
import com.example.ui.viewmodel.AuthSessionState
import com.example.ui.viewmodel.MobilePeViewModel
import com.example.util.NotificationHelper

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        NotificationHelper.ensureChannel(this)
        setContent {
            MobilePeTheme {
                MobilePeRoot()
            }
        }
    }
}

private data class TopLevelNavItem(
    val route: Any,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector,
    val tag: String
)

@Composable
private fun MobilePeRoot(viewModel: MobilePeViewModel = viewModel()) {
    val authState by viewModel.authState.collectAsStateWithLifecycle()

    when (authState) {
        AuthSessionState.Loading -> {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                CircularProgressIndicator()
            }
        }
        AuthSessionState.Unauthenticated -> {
            AuthScreen(viewModel = viewModel)
        }
        is AuthSessionState.Authenticated -> {
            MobilePeAuthenticatedApp(viewModel = viewModel)
        }
    }
}

@Composable
private fun MobilePeAuthenticatedApp(viewModel: MobilePeViewModel) {
    val context = LocalContext.current
    val navController = rememberNavController()
    val unreadCount by viewModel.unreadNotificationCount.collectAsStateWithLifecycle()

    val notifPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU &&
            !NotificationHelper.hasNotificationPermission(context)
        ) {
            notifPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    val topLevelItems = listOf(
        TopLevelNavItem(HomeRoute, "Home", Icons.Filled.Home, Icons.Outlined.Home, "nav_home"),
        TopLevelNavItem(ScannerRoute, "Scan QR", Icons.Filled.QrCodeScanner, Icons.Outlined.QrCodeScanner, "nav_scanner"),
        TopLevelNavItem(HistoryRoute, "History", Icons.Filled.History, Icons.Outlined.History, "nav_history"),
        TopLevelNavItem(NotificationsRoute, "Alerts", Icons.Filled.Notifications, Icons.Outlined.Notifications, "nav_alerts"),
        TopLevelNavItem(ProfileRoute, "Profile", Icons.Filled.Person, Icons.Outlined.Person, "nav_profile")
    )

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentDestination = navBackStackEntry?.destination
    val showTopLevelChrome = currentDestination?.let { dest ->
        dest.hasRoute<HomeRoute>() ||
            dest.hasRoute<HistoryRoute>() ||
            dest.hasRoute<NotificationsRoute>() ||
            dest.hasRoute<ProfileRoute>()
    } ?: true

    fun navigateTopLevel(route: Any) {
        navController.navigate(route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val useRail = maxWidth >= 600.dp

        Scaffold(
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            bottomBar = {
                if (showTopLevelChrome && !useRail) {
                    NavigationBar {
                        topLevelItems.forEach { item ->
                            val selected = when (item.route) {
                                HomeRoute -> currentDestination?.hasRoute<HomeRoute>() == true
                                ScannerRoute -> currentDestination?.hasRoute<ScannerRoute>() == true
                                HistoryRoute -> currentDestination?.hasRoute<HistoryRoute>() == true
                                NotificationsRoute -> currentDestination?.hasRoute<NotificationsRoute>() == true
                                ProfileRoute -> currentDestination?.hasRoute<ProfileRoute>() == true
                                else -> false
                            }
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateTopLevel(item.route) },
                                modifier = Modifier.testTag(item.tag),
                                icon = {
                                    if (item.route == NotificationsRoute && unreadCount > 0) {
                                        BadgedBox(
                                            badge = {
                                                Badge { Text(if (unreadCount > 9) "9+" else unreadCount.toString()) }
                                            }
                                        ) {
                                            Icon(
                                                imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                                contentDescription = item.label
                                            )
                                        }
                                    } else {
                                        Icon(
                                            imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                            contentDescription = item.label
                                        )
                                    }
                                },
                                label = { Text(item.label, maxLines = 1) }
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (showTopLevelChrome && useRail) {
                    NavigationRail(
                        header = {
                            Spacer(Modifier.padding(top = 8.dp))
                            MobilePeLogoMark(size = 38.dp, cornerRadius = 10.dp)
                        }
                    ) {
                        topLevelItems.forEach { item ->
                            val selected = when (item.route) {
                                HomeRoute -> currentDestination?.hasRoute<HomeRoute>() == true
                                ScannerRoute -> currentDestination?.hasRoute<ScannerRoute>() == true
                                HistoryRoute -> currentDestination?.hasRoute<HistoryRoute>() == true
                                NotificationsRoute -> currentDestination?.hasRoute<NotificationsRoute>() == true
                                ProfileRoute -> currentDestination?.hasRoute<ProfileRoute>() == true
                                else -> false
                            }
                            NavigationRailItem(
                                selected = selected,
                                onClick = { navigateTopLevel(item.route) },
                                icon = {
                                    if (item.route == NotificationsRoute && unreadCount > 0) {
                                        BadgedBox(
                                            badge = {
                                                Badge { Text(if (unreadCount > 9) "9+" else unreadCount.toString()) }
                                            }
                                        ) {
                                            Icon(
                                                imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                                contentDescription = item.label
                                            )
                                        }
                                    } else {
                                        Icon(
                                            imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                            contentDescription = item.label
                                        )
                                    }
                                },
                                label = { Text(item.label) }
                            )
                        }
                    }
                }

                NavHost(
                    navController = navController,
                    startDestination = HomeRoute,
                    modifier = Modifier.weight(1f)
                ) {
                    composable<HomeRoute> {
                        HomeScreen(
                            viewModel = viewModel,
                            onOpenScanner = { navController.navigate(ScannerRoute) },
                            onOpenNotifications = { navigateTopLevel(NotificationsRoute) },
                            onOpenProfile = { navigateTopLevel(ProfileRoute) },
                            onOpenHistory = { navigateTopLevel(HistoryRoute) },
                            onOpenTransfer = { mode, title, target ->
                                navController.navigate(
                                    TransferRoute(
                                        mode = mode,
                                        prefillTitle = title,
                                        prefillTarget = target,
                                        category = "TRANSFER"
                                    )
                                )
                            },
                            onOpenBills = { category ->
                                navController.navigate(BillsRoute(initialCategory = category))
                            },
                            onOpenCheckBalance = {
                                navController.navigate(CheckBalanceRoute)
                            }
                        )
                    }

                    composable<ScannerRoute> {
                        ScannerScreen(
                            viewModel = viewModel,
                            onBack = { navController.popBackStack() },
                            onQrScanned = { payeeName, upiId, amount ->
                                navController.popBackStack()
                                navController.navigate(
                                    TransferRoute(
                                        mode = "QR",
                                        prefillTitle = payeeName,
                                        prefillTarget = upiId,
                                        prefillAmount = amount,
                                        category = "QR_PAY"
                                    )
                                )
                            }
                        )
                    }

                    composable<HistoryRoute> {
                        HistoryScreen(
                            viewModel = viewModel,
                            onRepeatPayment = { txn ->
                                navController.navigate(
                                    TransferRoute(
                                        mode = if (txn.category == "QR_PAY") "QR" else "MOBILE",
                                        prefillTitle = txn.title,
                                        prefillTarget = txn.subtitle,
                                        prefillAmount = txn.amount.toInt().toString(),
                                        category = txn.category
                                    )
                                )
                            }
                        )
                    }

                    composable<NotificationsRoute> {
                        NotificationsScreen(viewModel = viewModel)
                    }

                    composable<ProfileRoute> {
                        ProfileScreen(viewModel = viewModel)
                    }

                    composable<TransferRoute> { backStackEntry ->
                        val route = backStackEntry.toRoute<TransferRoute>()
                        PaymentFlowScreen(
                            viewModel = viewModel,
                            mode = route.mode,
                            prefillTitle = route.prefillTitle,
                            prefillTarget = route.prefillTarget,
                            prefillAmount = route.prefillAmount,
                            category = route.category,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable<BillsRoute> { backStackEntry ->
                        val route = backStackEntry.toRoute<BillsRoute>()
                        BillsScreen(
                            viewModel = viewModel,
                            initialCategory = route.initialCategory,
                            onBack = { navController.popBackStack() }
                        )
                    }

                    composable<CheckBalanceRoute> {
                        CheckBalanceScreen(
                            viewModel = viewModel,
                            onBack = { navController.popBackStack() }
                        )
                    }
                }
            }
        }
    }
}
