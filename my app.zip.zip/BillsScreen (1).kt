package com.example.ui.screens

import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.PaymentOutcome
import com.example.data.model.TransactionEntity
import com.example.ui.components.DailyLimitProgressCard
import com.example.ui.components.PaymentReceiptDialog
import com.example.ui.components.UpiPinBottomSheet
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.CrimsonSoft
import com.example.ui.theme.PrimaryPurple
import com.example.ui.viewmodel.MobilePeViewModel
import com.example.util.PaymentUtils
import kotlinx.coroutines.launch

private data class BillCategorySpec(
    val id: String,
    val label: String,
    val icon: ImageVector,
    val providers: List<String>,
    val consumerLabel: String,
    val sampleConsumer: String,
    val samplePlans: List<Pair<String, String>>,
    val txnCategory: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BillsScreen(
    viewModel: MobilePeViewModel,
    initialCategory: String,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val user by viewModel.userProfile.collectAsStateWithLifecycle()
    val sources by viewModel.paymentSources.collectAsStateWithLifecycle()

    val categories = remember {
        listOf(
            BillCategorySpec(
                id = "MOBILE_RECHARGE",
                label = "Mobile",
                icon = Icons.Default.PhoneAndroid,
                providers = listOf("Jio Prepaid", "Airtel Prepaid", "Vi Prepaid", "BSNL"),
                consumerLabel = "10-Digit Mobile Number",
                sampleConsumer = "9876543210",
                samplePlans = listOf("299" to "28D • 2GB/day", "666" to "84D • 1.5GB/day", "2999" to "365D • 2.5GB/day"),
                txnCategory = "RECHARGE"
            ),
            BillCategorySpec(
                id = "DTH",
                label = "DTH",
                icon = Icons.Default.Tv,
                providers = listOf("Tata Play", "Airtel Digital TV", "Dish TV", "Sun Direct"),
                consumerLabel = "Subscriber / VC Number",
                sampleConsumer = "1048291044",
                samplePlans = listOf("350" to "Family Sports HD", "520" to "Mega Entertainment", "199" to "Hindi Starter"),
                txnCategory = "RECHARGE"
            ),
            BillCategorySpec(
                id = "ELECTRICITY",
                label = "Electricity",
                icon = Icons.Default.Bolt,
                providers = listOf("Adani Electricity", "Tata Power", "MSEDCL Mahavitaran", "BESCOM"),
                consumerLabel = "Consumer Number",
                sampleConsumer = "1009482711",
                samplePlans = listOf("1480" to "Monthly Bill", "2850" to "Due Bill", "6200" to "Commercial"),
                txnCategory = "BILL_PAY"
            ),
            BillCategorySpec(
                id = "CREDIT_CARD",
                label = "Credit Card",
                icon = Icons.Default.CreditCard,
                providers = listOf("HDFC Credit Card", "SBI Card", "ICICI Credit Card", "Axis Bank Card"),
                consumerLabel = "Last 4 Digits of Card",
                sampleConsumer = "4418",
                samplePlans = listOf("4500" to "Min Due", "18400" to "Total Statement", "25000" to "Custom"),
                txnCategory = "BILL_PAY"
            ),
            BillCategorySpec(
                id = "BROADBAND",
                label = "Broadband",
                icon = Icons.Default.Router,
                providers = listOf("JioFiber", "Airtel Xstream", "ACT Fibernet", "Tata Play Fiber"),
                consumerLabel = "Account / Landline ID",
                sampleConsumer = "0224819201",
                samplePlans = listOf("799" to "100 Mbps", "999" to "150 Mbps + OTT", "1499" to "300 Mbps"),
                txnCategory = "BILL_PAY"
            ),
            BillCategorySpec(
                id = "GAS",
                label = "Gas",
                icon = Icons.Default.LocalFireDepartment,
                providers = listOf("Mahanagar Gas", "Indane LPG", "HP Gas", "Bharat Gas"),
                consumerLabel = "CA Number / LPG ID",
                sampleConsumer = "4200918273",
                samplePlans = listOf("890" to "Cylinder Refill", "1240" to "Piped Gas Due"),
                txnCategory = "BILL_PAY"
            ),
            BillCategorySpec(
                id = "WATER",
                label = "Water",
                icon = Icons.Default.WaterDrop,
                providers = listOf("BMC Water", "Delhi Jal Board", "BWSSB Bengaluru"),
                consumerLabel = "K-Number / Connection ID",
                sampleConsumer = "77120944",
                samplePlans = listOf("460" to "Bi-monthly Bill", "920" to "Quarterly Bill"),
                txnCategory = "BILL_PAY"
            ),
            BillCategorySpec(
                id = "FASTAG",
                label = "FASTag",
                icon = Icons.Default.DirectionsCar,
                providers = listOf("Paytm FASTag", "ICICI FASTag", "HDFC FASTag", "SBI FASTag"),
                consumerLabel = "Vehicle Registration No.",
                sampleConsumer = "MH01AB4521",
                samplePlans = listOf("500" to "Quick Top-up", "1000" to "Highway Pack", "2000" to "Long Trip"),
                txnCategory = "RECHARGE"
            )
        )
    }

    var selectedCategoryId by remember { mutableStateOf(initialCategory) }
    val activeCategory = categories.firstOrNull { it.id == selectedCategoryId } ?: categories.first()

    var selectedProvider by remember(activeCategory.id) { mutableStateOf(activeCategory.providers.first()) }
    var consumerNumber by remember(activeCategory.id) { mutableStateOf(activeCategory.sampleConsumer) }
    var amountInput by remember(activeCategory.id) { mutableStateOf(activeCategory.samplePlans.first().first) }
    var selectedSourceId by remember(sources) {
        mutableStateOf(sources.firstOrNull()?.id ?: "WALLET")
    }

    var formError by remember { mutableStateOf<String?>(null) }
    var showPinSheet by remember { mutableStateOf(false) }
    var pinError by remember { mutableStateOf<String?>(null) }
    var receipt by remember { mutableStateOf<TransactionEntity?>(null) }
    var limitWarning by remember { mutableStateOf<PaymentOutcome.LimitExceeded?>(null) }

    val dailySpent = viewModel.effectiveDailySpent(user)
    val remaining = viewModel.remainingDailyLimit(user)
    val amt = amountInput.toDoubleOrNull() ?: 0.0

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Recharge & Bill Payments") },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = PrimaryPurple,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .imePadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 560.dp)
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(vertical = 2.dp)
                ) {
                    items(categories) { cat ->
                        FilterChip(
                            selected = cat.id == activeCategory.id,
                            onClick = { selectedCategoryId = cat.id; formError = null },
                            label = { Text(cat.label) },
                            leadingIcon = {
                                Icon(cat.icon, contentDescription = null)
                            }
                        )
                    }
                }

                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(18.dp))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        DailyLimitProgressCard(dailySpent = dailySpent)
                    }
                }

                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(20.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Text(
                            text = "Select Provider",
                            style = MaterialTheme.typography.labelLarge,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(activeCategory.providers) { provider ->
                                FilterChip(
                                    selected = provider == selectedProvider,
                                    onClick = { selectedProvider = provider },
                                    label = { Text(provider) }
                                )
                            }
                        }

                        OutlinedTextField(
                            value = consumerNumber,
                            onValueChange = { consumerNumber = it; formError = null },
                            label = { Text(activeCategory.consumerLabel) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("bill_consumer_input")
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Popular Plans / Bills",
                                style = MaterialTheme.typography.labelLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            OutlinedButton(
                                onClick = {
                                    amountInput = activeCategory.samplePlans.random().first
                                },
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("Fetch Bill")
                            }
                        }

                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(activeCategory.samplePlans) { (planAmt, desc) ->
                                Surface(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable { amountInput = planAmt; formError = null }
                                        .border(
                                            1.dp,
                                            if (amountInput == planAmt) PrimaryPurple else MaterialTheme.colorScheme.outline,
                                            RoundedCornerShape(12.dp)
                                        ),
                                    color = if (amountInput == planAmt) MaterialTheme.colorScheme.primaryContainer
                                    else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)
                                ) {
                                    Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)) {
                                        Text("₹$planAmt", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                                        Text(desc, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }

                        OutlinedTextField(
                            value = amountInput,
                            onValueChange = { raw ->
                                amountInput = raw.filter { it.isDigit() || it == '.' }
                                formError = null
                            },
                            label = { Text("Bill / Recharge Amount (₹)") },
                            prefix = { Text("₹ ") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            isError = amt > remaining,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("bill_amount_input")
                        )

                        if (amt > remaining) {
                            Surface(color = CrimsonSoft, shape = RoundedCornerShape(12.dp)) {
                                Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.WarningAmber, contentDescription = null, tint = CrimsonError)
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        text = "Exceeds ₹1,00,000 daily limit. Remaining today: ${PaymentUtils.formatInr(remaining)}.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = CrimsonError
                                    )
                                }
                            }
                        }
                    }
                }

                // Source Selection
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(20.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Pay With", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            items(sources) { src ->
                                FilterChip(
                                    selected = src.id == selectedSourceId,
                                    onClick = { selectedSourceId = src.id },
                                    label = { Text("${src.label} (${PaymentUtils.formatInr(src.availableBalance)})") }
                                )
                            }
                        }
                    }
                }

                if (formError != null) {
                    Text(formError!!, color = CrimsonError, style = MaterialTheme.typography.bodyMedium)
                }

                Button(
                    onClick = {
                        if (consumerNumber.isBlank()) {
                            formError = "Enter ${activeCategory.consumerLabel}."
                            return@Button
                        }
                        if (amt <= 0.0) {
                            formError = "Enter a valid amount."
                            return@Button
                        }
                        pinError = null
                        showPinSheet = true
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("pay_bill_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple)
                ) {
                    Text(
                        text = "Pay ${PaymentUtils.formatInr(amt)} Bill",
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            }
        }
    }

    if (showPinSheet) {
        val selectedSource = sources.firstOrNull { it.id == selectedSourceId } ?: sources.firstOrNull()
        UpiPinBottomSheet(
            title = selectedProvider,
            subtitle = consumerNumber,
            amountLabel = PaymentUtils.formatInr(amt),
            errorMessage = pinError,
            onDismiss = { showPinSheet = false; pinError = null },
            onPinSubmitted = { pin ->
                if (selectedSource == null) {
                    pinError = "No payment source selected"
                    return@UpiPinBottomSheet
                }
                scope.launch {
                    val outcome = viewModel.executePayment(
                        recipientTitle = selectedProvider,
                        recipientSubtitle = "${activeCategory.label} • $consumerNumber",
                        amount = amt,
                        category = activeCategory.txnCategory,
                        source = selectedSource,
                        enteredPin = pin
                    )
                    when (outcome) {
                        is PaymentOutcome.Success -> {
                            showPinSheet = false
                            pinError = null
                            receipt = outcome.transaction
                        }
                        is PaymentOutcome.InvalidPin -> pinError = outcome.message
                        is PaymentOutcome.InsufficientBalance -> {
                            pinError = "Insufficient balance (${PaymentUtils.formatInr(outcome.available)})"
                        }
                        is PaymentOutcome.LimitExceeded -> {
                            showPinSheet = false
                            pinError = null
                            limitWarning = outcome
                        }
                        is PaymentOutcome.Error -> pinError = outcome.message
                    }
                }
            }
        )
    }

    limitWarning?.let { exceeded ->
        AlertDialog(
            onDismissRequest = { limitWarning = null },
            icon = { Icon(Icons.Default.WarningAmber, contentDescription = null, tint = CrimsonError) },
            title = { Text("Daily Limit Exceeded") },
            text = {
                Text(
                    "Mobile pe enforces a ₹1,00,000 daily transaction limit. " +
                        "Remaining today: ${PaymentUtils.formatInr(exceeded.remainingToday)}."
                )
            },
            confirmButton = {
                Button(onClick = { limitWarning = null }, colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple)) {
                    Text("OK")
                }
            }
        )
    }

    receipt?.let { txn ->
        PaymentReceiptDialog(
            transaction = txn,
            onDismiss = {
                receipt = null
                onBack()
            }
        )
    }
}
