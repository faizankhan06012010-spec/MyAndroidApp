package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.example.ui.components.MobilePeLogoMark
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.DeepViolet
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.PrimaryPurple
import com.example.ui.viewmodel.MobilePeViewModel
import com.example.util.PaymentUtils
import kotlinx.coroutines.launch

private enum class AuthMethod { AADHAAR, MOBILE }

@Composable
fun AuthScreen(viewModel: MobilePeViewModel) {
    val scope = rememberCoroutineScope()
    var authMethod by remember { mutableStateOf(AuthMethod.AADHAAR) }

    var aadhaarInput by remember { mutableStateOf("") }
    var mobileInput by remember { mutableStateOf("") }
    var fullNameInput by remember { mutableStateOf("") }
    var otpInput by remember { mutableStateOf("") }
    var upiPinInput by remember { mutableStateOf("") }

    var otpSent by remember { mutableStateOf(false) }
    var existingUserFound by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    var errorText by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .imePadding()
                .navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Branded Hero Header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        Brush.linearGradient(
                            colors = listOf(ElectricViolet, PrimaryPurple, DeepViolet)
                        )
                    )
                    .statusBarsPadding()
                    .padding(horizontal = 24.dp, vertical = 28.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .widthIn(max = 560.dp)
                        .align(Alignment.Center),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    MobilePeLogoMark(size = 72.dp, cornerRadius = 20.dp)
                    Spacer(Modifier.height(14.dp))
                    Text(
                        text = "Mobile pe",
                        style = MaterialTheme.typography.displaySmall,
                        color = Color.White
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        text = "Fast UPI Transfers • Bills • QR Scan • ₹1,00,000/day Limit",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Color.White.copy(alpha = 0.88f),
                        textAlign = TextAlign.Center
                    )
                }
            }

            // Main Login Card
            Column(
                modifier = Modifier
                    .widthIn(max = 560.dp)
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "Sign in to Mobile pe",
                            style = MaterialTheme.typography.headlineSmall,
                            fontWeight = FontWeight.Bold
                        )

                        // Toggle between Aadhaar Number Login & Mobile Number Login
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(modifier = Modifier.padding(4.dp)) {
                                AuthTabButton(
                                    label = "Aadhaar Number",
                                    icon = Icons.Default.Badge,
                                    selected = authMethod == AuthMethod.AADHAAR,
                                    onClick = {
                                        authMethod = AuthMethod.AADHAAR
                                        otpSent = false
                                        existingUserFound = false
                                        errorText = null
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("tab_aadhaar_login")
                                )
                                AuthTabButton(
                                    label = "Mobile Number",
                                    icon = Icons.Default.PhoneAndroid,
                                    selected = authMethod == AuthMethod.MOBILE,
                                    onClick = {
                                        authMethod = AuthMethod.MOBILE
                                        otpSent = false
                                        existingUserFound = false
                                        errorText = null
                                    },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("tab_mobile_login")
                                )
                            }
                        }

                        if (authMethod == AuthMethod.AADHAAR) {
                            OutlinedTextField(
                                value = PaymentUtils.formatAadhaarGrouped(aadhaarInput),
                                onValueChange = { raw ->
                                    val digits = raw.filter { it.isDigit() }.take(12)
                                    aadhaarInput = digits
                                    otpSent = false
                                    existingUserFound = false
                                    errorText = null
                                },
                                label = { Text("12-Digit Aadhaar Card Number") },
                                placeholder = { Text("XXXX XXXX XXXX") },
                                leadingIcon = {
                                    Icon(Icons.Default.Badge, contentDescription = null, tint = PrimaryPurple)
                                },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("aadhaar_number_input")
                            )

                            Surface(
                                color = EmeraldSoft,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.VerifiedUser,
                                        contentDescription = null,
                                        tint = EmeraldSuccess,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        text = "Aadhaar e-KYC login unlocks ₹1,00,000 daily UPI limit & masked privacy protection.",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = EmeraldSuccess
                                    )
                                }
                            }
                        } else {
                            OutlinedTextField(
                                value = mobileInput,
                                onValueChange = { raw ->
                                    mobileInput = raw.filter { it.isDigit() }.take(10)
                                    otpSent = false
                                    existingUserFound = false
                                    errorText = null
                                },
                                label = { Text("10-Digit Mobile Number") },
                                placeholder = { Text("9876543210") },
                                prefix = { Text("+91 ") },
                                leadingIcon = {
                                    Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = PrimaryPurple)
                                },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                singleLine = true,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("mobile_number_input")
                            )
                        }

                        AnimatedVisibility(visible = otpSent) {
                            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                if (!existingUserFound) {
                                    OutlinedTextField(
                                        value = fullNameInput,
                                        onValueChange = { fullNameInput = it; errorText = null },
                                        label = { Text("Full Name (as on Bank / Aadhaar)") },
                                        singleLine = true,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .testTag("full_name_input")
                                    )
                                    if (authMethod == AuthMethod.AADHAAR) {
                                        OutlinedTextField(
                                            value = mobileInput,
                                            onValueChange = {
                                                mobileInput = it.filter { ch -> ch.isDigit() }.take(10)
                                                errorText = null
                                            },
                                            label = { Text("Aadhaar-Linked Mobile Number") },
                                            prefix = { Text("+91 ") },
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                            singleLine = true,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .testTag("linked_mobile_input")
                                        )
                                    }
                                }

                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.55f),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = "Demo OTP sent: ${PaymentUtils.DEMO_OTP}",
                                        style = MaterialTheme.typography.labelMedium.copy(fontFamily = JetBrainsMonoFamily),
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                                    )
                                }

                                OutlinedTextField(
                                    value = otpInput,
                                    onValueChange = {
                                        otpInput = it.filter { ch -> ch.isDigit() }.take(6)
                                        errorText = null
                                    },
                                    label = { Text("6-Digit OTP") },
                                    placeholder = { Text("123456") },
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("otp_input")
                                )

                                OutlinedTextField(
                                    value = upiPinInput,
                                    onValueChange = {
                                        upiPinInput = it.filter { ch -> ch.isDigit() }.take(4)
                                        errorText = null
                                    },
                                    label = {
                                        Text(
                                            if (existingUserFound) "Enter your 4-Digit Mobile pe PIN"
                                            else "Create 4-Digit UPI PIN"
                                        )
                                    },
                                    placeholder = { Text("••••") },
                                    leadingIcon = {
                                        Icon(Icons.Default.Lock, contentDescription = null, tint = PrimaryPurple)
                                    },
                                    visualTransformation = PasswordVisualTransformation(),
                                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("upi_pin_input")
                                )
                            }
                        }

                        if (errorText != null) {
                            Text(
                                text = errorText!!,
                                style = MaterialTheme.typography.bodyMedium,
                                color = CrimsonError
                            )
                        }

                        Button(
                            onClick = {
                                scope.launch {
                                    errorText = null
                                    if (!otpSent) {
                                        if (authMethod == AuthMethod.AADHAAR) {
                                            if (!PaymentUtils.isValidAadhaarFormat(aadhaarInput)) {
                                                errorText = "Enter a valid 12-digit Aadhaar number (first digit 2-9)."
                                                return@launch
                                            }
                                            isLoading = true
                                            val existing = viewModel.checkExistingAadhaar(aadhaarInput)
                                            existingUserFound = existing != null
                                            if (existing != null) fullNameInput = existing.fullName
                                            otpInput = PaymentUtils.DEMO_OTP
                                            otpSent = true
                                            isLoading = false
                                        } else {
                                            if (!PaymentUtils.isValidMobile(mobileInput)) {
                                                errorText = "Enter a valid 10-digit Indian mobile number."
                                                return@launch
                                            }
                                            isLoading = true
                                            val existing = viewModel.checkExistingMobile(mobileInput)
                                            existingUserFound = existing != null
                                            if (existing != null) fullNameInput = existing.fullName
                                            otpInput = PaymentUtils.DEMO_OTP
                                            otpSent = true
                                            isLoading = false
                                        }
                                    } else {
                                        if (otpInput != PaymentUtils.DEMO_OTP) {
                                            errorText = "Invalid OTP. Use ${PaymentUtils.DEMO_OTP}."
                                            return@launch
                                        }
                                        isLoading = true
                                        val result = if (authMethod == AuthMethod.AADHAAR) {
                                            viewModel.loginWithAadhaar(
                                                aadhaarDigits = aadhaarInput,
                                                fullName = fullNameInput,
                                                mobileDigits = mobileInput,
                                                upiPin = upiPinInput
                                            )
                                        } else {
                                            viewModel.loginWithMobile(
                                                mobileDigits = mobileInput,
                                                fullName = fullNameInput,
                                                upiPin = upiPinInput
                                            )
                                        }
                                        isLoading = false
                                        result.onFailure { errorText = it.message ?: "Login failed" }
                                    }
                                }
                            },
                            enabled = !isLoading,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(52.dp)
                                .testTag("auth_submit_button"),
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple)
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(22.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Text(
                                    text = if (!otpSent) "Verify & Send OTP" else "Verify OTP & Continue",
                                    style = MaterialTheme.typography.titleMedium
                                )
                            }
                        }
                    }
                }

                // Instant Demo Aadhaar Login Card
                OutlinedButton(
                    onClick = { viewModel.loginDemoAadhaar() },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("demo_aadhaar_login_button"),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Icon(Icons.Default.Shield, contentDescription = null, tint = PrimaryPurple)
                    Spacer(Modifier.width(8.dp))
                    Text("Quick Demo Sign-In (Aadhaar Verified • PIN 1234)")
                }

                Text(
                    text = "Protected by 256-bit encryption • ₹1,00,000 daily transaction safeguard",
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        }
    }
}

@Composable
private fun AuthTabButton(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .height(44.dp)
            .clip(RoundedCornerShape(11.dp))
            .clickable(onClick = onClick),
        color = if (selected) MaterialTheme.colorScheme.surface else Color.Transparent,
        shadowElevation = if (selected) 2.dp else 0.dp,
        shape = RoundedCornerShape(11.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxSize(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (selected) PrimaryPurple else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(17.dp)
            )
            Spacer(Modifier.width(6.dp))
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = if (selected) PrimaryPurple else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}
