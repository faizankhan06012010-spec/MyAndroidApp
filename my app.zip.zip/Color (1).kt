package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val PrimaryPurple = Color(0xFF5F259F)
val ElectricViolet = Color(0xFF7A09EF)
val DeepViolet = Color(0xFF41009B)
val SoftLavender = Color(0xFFF3EBFF)
val LightSurface = Color(0xFFF7F5FB)
val CardWhite = Color(0xFFFFFFFF)
val BorderLavender = Color(0xFFE6DDF5)

val DarkBackground = Color(0xFF0E0B16)
val DarkSurface = Color(0xFF171224)
val DarkCard = Color(0xFF211A33)
val DarkLavender = Color(0xFFD5B8FF)

val EmeraldSuccess = Color(0xFF0E9F6E)
val EmeraldSoft = Color(0xFFE6F7F1)
val AmberWarning = Color(0xFFD97706)
val AmberSoft = Color(0xFFFEF3C7)
val CrimsonError = Color(0xFFDC2626)
val CrimsonSoft = Color(0xFFFEE2E2)
val SkyAccent = Color(0xFF0284C7)
val SkySoft = Color(0xFFE0F2FE)

val TextPrimaryLight = Color(0xFF1A1426)
val TextSecondaryLight = Color(0xFF635A75)
val TextPrimaryDark = Color(0xFFF5F2FA)
val TextSecondaryDark = Color(0xFFB3A9C7)
