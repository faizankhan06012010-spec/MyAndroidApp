package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.PaymentOutcome
import com.example.data.model.QuickContact
import com.example.data.model.TransactionEntity
import com.example.ui.components.AadhaarVerifiedPill
import com.example.ui.components.AddMoneyDialog
import com.example.ui.components.DailyLimitProgressCard
import com.example.ui.components.MobilePeLogoMark
import com.example.ui.components.PaymentReceiptDialog
import com.example.ui.components.UpiPinBottomSheet
import com.example.ui.theme.AmberWarning
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.DeepViolet
import com.example.ui.theme.ElectricViolet
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.PrimaryPurple
import com.example.ui.theme.SkyAccent
import com.example.ui.viewmodel.MobilePeViewModel
import com.example.util.PaymentUtils
import kotlinx.coroutines.launch

@Composable
fun HomeScreen(
    viewModel: MobilePeViewModel,
    onOpenScanner: () -> Unit,
    onOpenNotifications: () -> Unit,
    onOpenProfile: () -> Unit,
    onOpenHistory: () -> Unit,
    onOpenTransfer: (mode: String, title: String, target: String) -> Unit,
    onOpenBills: (category: String) -> Unit,
    onOpenCheckBalance: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }

    val user by viewModel.userProfile.collectAsStateWithLifecycle()
    val banks by viewModel.bankAccounts.collectAsStateWithLifecycle()
    val transactions by viewModel.transactions.collectAsStateWithLifecycle()
    val unreadCount by viewModel.unreadNotificationCount.collectAsStateWithLifecycle()
    val hideBalance by viewModel.hideBalance.collectAsStateWithLifecycle()

    var showAddMoneyDialog by remember { mutableStateOf(false) }
    var pendingAddMoney by remember { mutableStateOf<Pair<Long, Double>?>(null) }
    var pinError by remember { mutableStateOf<String?>(null) }
    var selectedReceipt by remember { mutableStateOf<TransactionEntity?>(null) }

    val dailySpent = viewModel.effectiveDailySpent(user)

    Scaffold(
        modifier = modifier.fillMaxSize(),
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding),
            contentPadding = PaddingValues(bottom = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top App Header
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Brush.verticalGradient(
                                colors = listOf(PrimaryPurple, ElectricViolet)
                            )
                        )
                        .padding(horizontal = 16.dp, vertical = 14.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .widthIn(max = 640.dp)
                            .fillMaxWidth()
                            .align(Alignment.Center),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .clip(RoundedCornerShape(14.dp))
                                .clickable(onClick = onOpenProfile)
                                .padding(4.dp)
                                .testTag("home_profile_button")
                        ) {
                            MobilePeLogoMark(size = 40.dp, cornerRadius = 12.dp)
                            Spacer(Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "Mobile pe",
                                    style = MaterialTheme.typography.titleLarge,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = user?.let { "${it.fullName} • ${it.city}" } ?: "UPI & Payments",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color.White.copy(alpha = 0.85f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }

                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = onOpenScanner,
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("home_top_scanner_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.QrCodeScanner,
                                    contentDescription = "Scan QR Code",
                                    tint = Color.White
                                )
                            }
                            IconButton(
                                onClick = onOpenNotifications,
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .testTag("home_notifications_button")
                            ) {
                                BadgedBox(
                                    badge = {
                                        if (unreadCount > 0) {
                                            Badge(containerColor = CrimsonError) {
                                                Text(
                                                    text = if (unreadCount > 9) "9+" else unreadCount.toString(),
                                                    color = Color.White
                                                )
                                            }
                                        }
                                    }
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Notifications,
                                        contentDescription = "Notifications",
                                        tint = Color.White
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Hero Balance & Daily ₹1,00,000 Limit Card
            item {
                Column(
                    modifier = Modifier
                        .widthIn(max = 640.dp)
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Card(
                        shape = RoundedCornerShape(24.dp),
                        elevation = CardDefaults.cardElevation(defaultElevation = 4.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    Brush.linearGradient(
                                        colors = listOf(DeepViolet, PrimaryPurple, ElectricViolet)
                                    )
                                )
                                .padding(18.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "Mobile pe Wallet",
                                            style = MaterialTheme.typography.labelLarge,
                                            color = Color.White.copy(alpha = 0.8f)
                                        )
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = if (hideBalance) "₹ ••••••" else PaymentUtils.formatInr(user?.walletBalance ?: 0.0),
                                                style = MaterialTheme.typography.displaySmall,
                                                color = Color.White
                                            )
                                            IconButton(
                                                onClick = { viewModel.toggleHideBalance() },
                                                modifier = Modifier.minimumInteractiveComponentSize()
                                            ) {
                                                Icon(
                                                    imageVector = if (hideBalance) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                                    contentDescription = "Toggle balance visibility",
                                                    tint = Color.White.copy(alpha = 0.85f)
                                                )
                                            }
                                        }
                                    }

                                    Surface(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(14.dp))
                                            .clickable { showAddMoneyDialog = true }
                                            .testTag("add_money_button"),
                                        color = Color.White.copy(alpha = 0.18f),
                                        shape = RoundedCornerShape(14.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Add,
                                                contentDescription = null,
                                                tint = Color.White,
                                                modifier = Modifier.size(18.dp)
                                            )
                                            Spacer(Modifier.width(4.dp))
                                            Text(
                                                text = "Add Money",
                                                style = MaterialTheme.typography.labelLarge,
                                                color = Color.White
                                            )
                                        }
                                    }
                                }

                                DailyLimitProgressCard(
                                    dailySpent = dailySpent,
                                    onDarkBackground = true
                                )

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    AadhaarVerifiedPill(maskedAadhaar = user?.maskedAadhaar)
                                    Text(
                                        text = "${banks.size} Bank(s) Linked",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = Color.White.copy(alpha = 0.85f)
                                    )
                                }
                            }
                        }
                    }

                    // My UPI ID Strip
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = MaterialTheme.colorScheme.surface,
                        tonalElevation = 1.dp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.QrCode2,
                                    contentDescription = null,
                                    tint = PrimaryPurple
                                )
                                Spacer(Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "My UPI ID",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = user?.upiId ?: "user@mobilepe",
                                        style = MaterialTheme.typography.bodyMedium.copy(fontFamily = JetBrainsMonoFamily),
                                        fontWeight = FontWeight.SemiBold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            Row {
                                IconButton(
                                    onClick = {
                                        val upi = user?.upiId ?: return@IconButton
                                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                        clipboard.setPrimaryClip(ClipData.newPlainText("UPI ID", upi))
                                        scope.launch { snackbarHostState.showSnackbar("Copied $upi") }
                                    },
                                    modifier = Modifier.minimumInteractiveComponentSize()
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContentCopy,
                                        contentDescription = "Copy UPI ID",
                                        tint = PrimaryPurple
                                    )
                                }
                            }
                        }
                    }

                    // Money Transfers Section
                    SectionCard(title = "Money Transfers") {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            ActionGridItem(
                                icon = Icons.Default.Person,
                                label = "To Mobile\nNumber",
                                tint = PrimaryPurple,
                                onClick = { onOpenTransfer("MOBILE", "", "") },
                                modifier = Modifier.weight(1f).testTag("action_to_mobile")
                            )
                            ActionGridItem(
                                icon = Icons.Default.AccountBalance,
                                label = "To Bank /\nUPI ID",
                                tint = ElectricViolet,
                                onClick = { onOpenTransfer("BANK", "", "") },
                                modifier = Modifier.weight(1f).testTag("action_to_bank")
                            )
                            ActionGridItem(
                                icon = Icons.Default.SwapHoriz,
                                label = "To Self\nAccount",
                                tint = SkyAccent,
                                onClick = { onOpenTransfer("SELF", "Self Transfer", "") },
                                modifier = Modifier.weight(1f).testTag("action_to_self")
                            )
                            ActionGridItem(
                                icon = Icons.Default.AccountBalanceWallet,
                                label = "Check Bank\nBalance",
                                tint = EmeraldSuccess,
                                onClick = onOpenCheckBalance,
                                modifier = Modifier.weight(1f).testTag("action_check_balance")
                            )
                        }
                    }

                    // Quick Pay Contacts
                    SectionCard(title = "Quick Pay & Merchants") {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            items(viewModel.quickContacts) { contact ->
                                QuickContactChip(
                                    contact = contact,
                                    onClick = {
                                        onOpenTransfer("MOBILE", contact.name, contact.mobileOrUpi)
                                    }
                                )
                            }
                        }
                    }

                    // Recharge & Bill Payments Section
                    SectionCard(title = "Recharge & Bill Payments") {
                        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                            Row(modifier = Modifier.fillMaxWidth()) {
                                ActionGridItem(
                                    icon = Icons.Default.PhoneAndroid,
                                    label = "Mobile\nRecharge",
                                    tint = PrimaryPurple,
                                    onClick = { onOpenBills("MOBILE_RECHARGE") },
                                    modifier = Modifier.weight(1f).testTag("bill_mobile")
                                )
                                ActionGridItem(
                                    icon = Icons.Default.Tv,
                                    label = "DTH",
                                    tint = ElectricViolet,
                                    onClick = { onOpenBills("DTH") },
                                    modifier = Modifier.weight(1f).testTag("bill_dth")
                                )
                                ActionGridItem(
                                    icon = Icons.Default.Bolt,
                                    label = "Electricity",
                                    tint = AmberWarning,
                                    onClick = { onOpenBills("ELECTRICITY") },
                                    modifier = Modifier.weight(1f).testTag("bill_electricity")
                                )
                                ActionGridItem(
                                    icon = Icons.Default.CreditCard,
                                    label = "Credit Card\nBill",
                                    tint = SkyAccent,
                                    onClick = { onOpenBills("CREDIT_CARD") },
                                    modifier = Modifier.weight(1f).testTag("bill_credit_card")
                                )
                            }
                            Row(modifier = Modifier.fillMaxWidth()) {
                                ActionGridItem(
                                    icon = Icons.Default.Router,
                                    label = "Broadband",
                                    tint = PrimaryPurple,
                                    onClick = { onOpenBills("BROADBAND") },
                                    modifier = Modifier.weight(1f).testTag("bill_broadband")
                                )
                                ActionGridItem(
                                    icon = Icons.Default.LocalFireDepartment,
                                    label = "Piped Gas /\nCylinder",
                                    tint = CrimsonError,
                                    onClick = { onOpenBills("GAS") },
                                    modifier = Modifier.weight(1f).testTag("bill_gas")
                                )
                                ActionGridItem(
                                    icon = Icons.Default.WaterDrop,
                                    label = "Water Bill",
                                    tint = SkyAccent,
                                    onClick = { onOpenBills("WATER") },
                                    modifier = Modifier.weight(1f).testTag("bill_water")
                                )
                                ActionGridItem(
                                    icon = Icons.Default.DirectionsCar,
                                    label = "FASTag\nRecharge",
                                    tint = EmeraldSuccess,
                                    onClick = { onOpenBills("FASTAG") },
                                    modifier = Modifier.weight(1f).testTag("bill_fastag")
                                )
                            }
                        }
                    }

                    // Recent Transactions Preview
                    SectionCard(
                        title = "Recent Transactions",
                        trailingAction = {
                            TextButton(onClick = onOpenHistory) {
                                Text("View All")
                                Spacer(Modifier.width(2.dp))
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                    contentDescription = null,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    ) {
                        if (transactions.isEmpty()) {
                            Text(
                                text = "No transactions yet. Scan a QR or transfer money to get started!",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(vertical = 8.dp)
                            )
                        } else {
                            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                transactions.take(4).forEach { txn ->
                                    TransactionRowItem(
                                        transaction = txn,
                                        onClick = { selectedReceipt = txn }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddMoneyDialog) {
        AddMoneyDialog(
            banks = banks,
            onDismiss = { showAddMoneyDialog = false },
            onConfirmAmountAndBank = { bankId, amount ->
                showAddMoneyDialog = false
                pinError = null
                pendingAddMoney = bankId to amount
            }
        )
    }

    pendingAddMoney?.let { (bankId, amount) ->
        UpiPinBottomSheet(
            title = "Add Money to Wallet",
            subtitle = "From Linked Bank Account",
            amountLabel = PaymentUtils.formatInr(amount),
            errorMessage = pinError,
            onDismiss = { pendingAddMoney = null; pinError = null },
            onPinSubmitted = { pin ->
                scope.launch {
                    when (val outcome = viewModel.addMoneyToWallet(bankId, amount, pin)) {
                        is PaymentOutcome.Success -> {
                            pendingAddMoney = null
                            pinError = null
                            selectedReceipt = outcome.transaction
                        }
                        is PaymentOutcome.InvalidPin -> pinError = outcome.message
                        is PaymentOutcome.InsufficientBalance -> {
                            pinError = "Insufficient bank balance (${PaymentUtils.formatInr(outcome.available)})"
                        }
                        is PaymentOutcome.Error -> pinError = outcome.message
                        is PaymentOutcome.LimitExceeded -> Unit
                    }
                }
            }
        )
    }

    selectedReceipt?.let { txn ->
        PaymentReceiptDialog(
            transaction = txn,
            onDismiss = { selectedReceipt = null }
        )
    }
}

@Composable
private fun SectionCard(
    title: String,
    trailingAction: (@Composable () -> Unit)? = null,
    content: @Composable () -> Unit
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.6f), RoundedCornerShape(20.dp))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                trailingAction?.invoke()
            }
            Spacer(Modifier.height(12.dp))
            content()
        }
    }
}

@Composable
private fun ActionGridItem(
    icon: ImageVector,
    label: String,
    tint: Color,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 6.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(50.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(tint.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = label.replace("\n", " "),
                tint = tint,
                modifier = Modifier.size(26.dp)
            )
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = label,
            style = MaterialTheme.typography.labelMedium,
            textAlign = TextAlign.Center,
            lineHeight = MaterialTheme.typography.labelMedium.lineHeight,
            maxLines = 2
        )
    }
}

@Composable
private fun QuickContactChip(contact: QuickContact, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .width(68.dp)
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val initials = contact.name.split(" ")
            .take(2)
            .mapNotNull { it.firstOrNull()?.uppercaseChar() }
            .joinToString("")
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(Color(contact.avatarBgHex)),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = initials,
                style = MaterialTheme.typography.titleSmall,
                color = Color.White,
                fontWeight = FontWeight.Bold
            )
        }
        Spacer(Modifier.height(6.dp))
        Text(
            text = contact.name.substringBefore(" "),
            style = MaterialTheme.typography.labelMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
    }
}

@Composable
fun TransactionRowItem(
    transaction: TransactionEntity,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isCredit = transaction.direction == "CREDIT"
    val isFailed = transaction.status == "FAILED"
    val badgeBg = when {
        isFailed -> MaterialTheme.colorScheme.errorContainer
        isCredit -> EmeraldSoft
        else -> MaterialTheme.colorScheme.primaryContainer
    }
    val badgeTint = when {
        isFailed -> CrimsonError
        isCredit -> EmeraldSuccess
        else -> PrimaryPurple
    }

    Row(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .padding(vertical = 8.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(badgeBg),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = if (isCredit) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                contentDescription = null,
                tint = badgeTint,
                modifier = Modifier.size(22.dp)
            )
        }
        Spacer(Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = transaction.title,
                style = MaterialTheme.typography.titleSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = PaymentUtils.formatShortTime(transaction.timestamp) +
                    if (isFailed) " • Failed" else " • ${transaction.paymentMethod}",
                style = MaterialTheme.typography.bodyMedium,
                color = if (isFailed) CrimsonError else MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(8.dp))
        Text(
            text = (if (isCredit) "+" else "-") + PaymentUtils.formatInr(transaction.amount),
            style = MaterialTheme.typography.titleSmall,
            fontWeight = FontWeight.Bold,
            color = when {
                isFailed -> CrimsonError
                isCredit -> EmeraldSuccess
                else -> MaterialTheme.colorScheme.onSurface
            }
        )
    }
}
