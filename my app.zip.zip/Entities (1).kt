package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "user_profiles")
data class UserProfileEntity(
    @PrimaryKey val uid: String,
    val fullName: String,
    val mobileNumber: String,
    val upiId: String,
    val aadhaarHash: String? = null,
    val maskedAadhaar: String? = null,
    val aadhaarVerified: Boolean = false,
    val upiPin: String,
    val walletBalance: Double = 25000.0,
    val dailySpent: Double = 0.0,
    val dailyLimitDate: String = "",
    val city: String = "Mumbai",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "bank_accounts")
data class BankAccountEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String,
    val bankName: String,
    val accountLast4: String,
    val ifscCode: String,
    val balance: Double,
    val isPrimary: Boolean = false,
    val accentColorHex: Long = 0xFF1D4ED8
)

@Entity(tableName = "transactions")
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String,
    val txnRef: String,
    val utrNumber: String,
    val title: String,
    val subtitle: String,
    val category: String,      // TRANSFER, QR_PAY, RECHARGE, BILL_PAY, ADD_MONEY, CREDIT
    val direction: String,     // DEBIT, CREDIT
    val amount: Double,
    val status: String,        // SUCCESS, FAILED
    val paymentMethod: String, // e.g., "Mobile pe Wallet", "SBI ••4821"
    val failureReason: String? = null,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "app_notifications")
data class AppNotificationEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userId: String,
    val title: String,
    val message: String,
    val type: String,          // PAYMENT_SENT, PAYMENT_RECEIVED, BILL_PAID, LIMIT_ALERT, SECURITY
    val amount: Double? = null,
    val isRead: Boolean = false,
    val timestamp: Long = System.currentTimeMillis()
)

data class QuickContact(
    val name: String,
    val mobileOrUpi: String,
    val isMerchant: Boolean = false,
    val avatarBgHex: Long = 0xFF5F259F
)

data class PaymentSourceOption(
    val id: String,            // "WALLET" or "BANK_<bankId>"
    val label: String,
    val sublabel: String,
    val availableBalance: Double,
    val isWallet: Boolean,
    val bankAccountId: Long? = null
)

sealed interface PaymentOutcome {
    data class Success(val transaction: TransactionEntity) : PaymentOutcome
    data class LimitExceeded(
        val requestedAmount: Double,
        val remainingToday: Double,
        val dailyLimit: Double
    ) : PaymentOutcome
    data class InsufficientBalance(val available: Double, val required: Double) : PaymentOutcome
    data class InvalidPin(val message: String) : PaymentOutcome
    data class Error(val message: String) : PaymentOutcome
}
