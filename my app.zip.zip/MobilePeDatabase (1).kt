package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.AppNotificationEntity
import com.example.data.model.BankAccountEntity
import com.example.data.model.TransactionEntity
import com.example.data.model.UserProfileEntity

@Database(
    entities = [
        UserProfileEntity::class,
        BankAccountEntity::class,
        TransactionEntity::class,
        AppNotificationEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class MobilePeDatabase : RoomDatabase() {
    abstract fun dao(): MobilePeDao

    companion object {
        @Volatile
        private var INSTANCE: MobilePeDatabase? = null

        fun getInstance(context: Context): MobilePeDatabase {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    MobilePeDatabase::class.java,
                    "mobile_pe_db"
                ).build().also { INSTANCE = it }
            }
        }
    }
}
