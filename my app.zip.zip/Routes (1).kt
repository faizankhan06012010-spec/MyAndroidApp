package com.example.ui.navigation

import kotlinx.serialization.Serializable

@Serializable
object HomeRoute

@Serializable
object ScannerRoute

@Serializable
object HistoryRoute

@Serializable
object NotificationsRoute

@Serializable
object ProfileRoute

@Serializable
data class TransferRoute(
    val mode: String = "MOBILE", // MOBILE, BANK, SELF, QR
    val prefillTitle: String = "",
    val prefillTarget: String = "",
    val prefillAmount: String = "",
    val category: String = "TRANSFER"
)

@Serializable
data class BillsRoute(
    val initialCategory: String = "MOBILE_RECHARGE"
)

@Serializable
object CheckBalanceRoute
