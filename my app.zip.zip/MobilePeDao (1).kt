package com.example.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.AppNotificationEntity
import com.example.data.model.BankAccountEntity
import com.example.data.model.TransactionEntity
import com.example.data.model.UserProfileEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MobilePeDao {

    @Query("SELECT * FROM user_profiles WHERE uid = :uid LIMIT 1")
    fun observeUser(uid: String): Flow<UserProfileEntity?>

    @Query("SELECT * FROM user_profiles WHERE uid = :uid LIMIT 1")
    suspend fun getUserById(uid: String): UserProfileEntity?

    @Query("SELECT * FROM user_profiles WHERE aadhaarHash = :aadhaarHash LIMIT 1")
    suspend fun getUserByAadhaarHash(aadhaarHash: String): UserProfileEntity?

    @Query("SELECT * FROM user_profiles WHERE mobileNumber = :mobile LIMIT 1")
    suspend fun getUserByMobile(mobile: String): UserProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: UserProfileEntity)

    @Update
    suspend fun updateUser(user: UserProfileEntity)

    @Query("SELECT * FROM bank_accounts WHERE userId = :userId ORDER BY isPrimary DESC, id ASC")
    fun observeBankAccounts(userId: String): Flow<List<BankAccountEntity>>

    @Query("SELECT * FROM bank_accounts WHERE userId = :userId ORDER BY isPrimary DESC, id ASC")
    suspend fun getBankAccounts(userId: String): List<BankAccountEntity>

    @Query("SELECT * FROM bank_accounts WHERE id = :bankId LIMIT 1")
    suspend fun getBankAccountById(bankId: Long): BankAccountEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBankAccount(account: BankAccountEntity): Long

    @Update
    suspend fun updateBankAccount(account: BankAccountEntity)

    @Query("UPDATE bank_accounts SET isPrimary = CASE WHEN id = :bankId THEN 1 ELSE 0 END WHERE userId = :userId")
    suspend fun setPrimaryBankAccount(userId: String, bankId: Long)

    @Query("SELECT * FROM transactions WHERE userId = :userId ORDER BY timestamp DESC")
    fun observeTransactions(userId: String): Flow<List<TransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTransaction(transaction: TransactionEntity): Long

    @Query("SELECT * FROM app_notifications WHERE userId = :userId ORDER BY timestamp DESC")
    fun observeNotifications(userId: String): Flow<List<AppNotificationEntity>>

    @Query("SELECT COUNT(*) FROM app_notifications WHERE userId = :userId AND isRead = 0")
    fun observeUnreadNotificationCount(userId: String): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertNotification(notification: AppNotificationEntity): Long

    @Query("UPDATE app_notifications SET isRead = 1 WHERE userId = :userId")
    suspend fun markAllNotificationsRead(userId: String)

    @Query("UPDATE app_notifications SET isRead = 1 WHERE id = :notificationId")
    suspend fun markNotificationRead(notificationId: Long)
}
