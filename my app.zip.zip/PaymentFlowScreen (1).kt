package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.BankAccountEntity
import com.example.data.model.PaymentOutcome
import com.example.data.model.TransactionEntity
import com.example.ui.components.DailyLimitProgressCard
import com.example.ui.components.PaymentReceiptDialog
import com.example.ui.components.UpiPinBottomSheet
import com.example.ui.theme.CrimsonError
import com.example.ui.theme.CrimsonSoft
import com.example.ui.theme.EmeraldSoft
import com.example.ui.theme.EmeraldSuccess
import com.example.ui.theme.PrimaryPurple
import com.example.ui.viewmodel.MobilePeViewModel
import com.example.util.PaymentUtils
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaymentFlowScreen(
    viewModel: MobilePeViewModel,
    mode: String,
    prefillTitle: String,
    prefillTarget: String,
    prefillAmount: String,
    category: String,
    onBack: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val user by viewModel.userProfile.collectAsStateWithLifecycle()
    val sources by viewModel.paymentSources.collectAsStateWithLifecycle()

    var recipientName by remember { mutableStateOf(prefillTitle) }
    var recipientTarget by remember { mutableStateOf(prefillTarget) }
    var ifscInput by remember { mutableStateOf("") }
    var amountInput by remember { mutableStateOf(prefillAmount) }
    var noteInput by remember { mutableStateOf("") }
    var selectedSourceId by remember(sources) {
        mutableStateOf(sources.firstOrNull { !it.isWallet }?.id ?: sources.firstOrNull()?.id ?: "WALLET")
    }

    var formError by remember { mutableStateOf<String?>(null) }
    var showPinSheet by remember { mutableStateOf(false) }
    var pinError by remember { mutableStateOf<String?>(null) }
    var completedReceipt by remember { mutableStateOf<TransactionEntity?>(null) }
    var limitWarningDialog by remember { mutableStateOf<PaymentOutcome.LimitExceeded?>(null) }

    val dailySpent = viewModel.effectiveDailySpent(user)
    val remainingLimit = viewModel.remainingDailyLimit(user)
    val enteredAmount = amountInput.toDoubleOrNull() ?: 0.0
    val exceedsDailyLimit = enteredAmount > remainingLimit

    val screenTitle = when (mode) {
        "QR" -> "Pay QR Merchant"
        "BANK" -> "Bank / UPI Transfer"
        "SELF" -> "Self Account Transfer"
        else -> "Send Money"
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(screenTitle) },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = PrimaryPurple,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .imePadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 560.dp)
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Daily ₹1,00,000 Limit Card
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(18.dp))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        DailyLimitProgressCard(dailySpent = dailySpent)
                    }
                }

                // Recipient Details Card
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(20.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        when (mode) {
                            "SELF" -> {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = PrimaryPurple)
                                    Spacer(Modifier.width(10.dp))
                                    Column {
                                        Text("Transfer to Mobile pe Wallet", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                        Text("Move funds from your linked bank account to wallet", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                            else -> {
                                OutlinedTextField(
                                    value = recipientTarget,
                                    onValueChange = { recipientTarget = it; formError = null },
                                    label = {
                                        Text(
                                            when (mode) {
                                                "BANK" -> "UPI ID or Bank Account Number"
                                                "QR" -> "Merchant UPI ID"
                                                else -> "Mobile Number or UPI ID"
                                            }
                                        )
                                    },
                                    leadingIcon = {
                                        Icon(
                                            if (mode == "QR") Icons.Default.QrCode2 else Icons.Default.Person,
                                            contentDescription = null,
                                            tint = PrimaryPurple
                                        )
                                    },
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("recipient_target_input")
                                )

                                OutlinedTextField(
                                    value = recipientName,
                                    onValueChange = { recipientName = it; formError = null },
                                    label = { Text("Recipient Name") },
                                    singleLine = true,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .testTag("recipient_name_input")
                                )

                                if (mode == "BANK" && !recipientTarget.contains("@")) {
                                    OutlinedTextField(
                                        value = ifscInput,
                                        onValueChange = { ifscInput = it.uppercase(); formError = null },
                                        label = { Text("IFSC Code (if bank account)") },
                                        placeholder = { Text("SBIN0001245") },
                                        singleLine = true,
                                        modifier = Modifier.fillMaxWidth()
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = amountInput,
                            onValueChange = { raw ->
                                amountInput = raw.filter { it.isDigit() || it == '.' }
                                formError = null
                            },
                            label = { Text("Amount (Max ₹1,00,000/day)") },
                            prefix = { Text("₹ ", style = MaterialTheme.typography.titleLarge) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            singleLine = true,
                            isError = exceedsDailyLimit,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("payment_amount_input")
                        )

                        // Quick Amount Presets
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("100", "500", "1000", "5000").forEach { preset ->
                                Surface(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable { amountInput = preset; formError = null },
                                    color = MaterialTheme.colorScheme.primaryContainer
                                ) {
                                    Text(
                                        text = "₹$preset",
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }

                        if (exceedsDailyLimit) {
                            Surface(
                                color = CrimsonSoft,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.WarningAmber, contentDescription = null, tint = CrimsonError)
                                    Spacer(Modifier.width(8.dp))
                                    Text(
                                        text = "Exceeds ₹1,00,000 daily limit! You have ${PaymentUtils.formatInr(remainingLimit)} remaining today.",
                                        style = MaterialTheme.typography.bodyMedium,
                                        color = CrimsonError
                                    )
                                }
                            }
                        }

                        OutlinedTextField(
                            value = noteInput,
                            onValueChange = { noteInput = it },
                            label = { Text("Add a message (optional)") },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }

                // Payment Source Selector
                Card(
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(20.dp))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = "Pay Using",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        sources.filter { mode != "SELF" || !it.isWallet }.forEach { source ->
                            val selected = source.id == selectedSourceId
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .clickable { selectedSourceId = source.id }
                                    .border(
                                        width = if (selected) 1.5.dp else 1.dp,
                                        color = if (selected) PrimaryPurple else MaterialTheme.colorScheme.outline,
                                        shape = RoundedCornerShape(14.dp)
                                    ),
                                color = if (selected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                                else Color.Transparent
                            ) {
                                Row(
                                    modifier = Modifier.padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    RadioButton(
                                        selected = selected,
                                        onClick = { selectedSourceId = source.id }
                                    )
                                    Spacer(Modifier.width(6.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(source.label, style = MaterialTheme.typography.titleSmall)
                                        Text(
                                            text = "Balance: ${PaymentUtils.formatInr(source.availableBalance)}",
                                            style = MaterialTheme.typography.bodyMedium,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                if (formError != null) {
                    Text(
                        text = formError!!,
                        style = MaterialTheme.typography.bodyMedium,
                        color = CrimsonError
                    )
                }

                Button(
                    onClick = {
                        val amt = amountInput.toDoubleOrNull()
                        if (amt == null || amt <= 0.0) {
                            formError = "Enter a valid payment amount."
                            return@Button
                        }
                        if (mode != "SELF" && recipientTarget.isBlank()) {
                            formError = "Enter recipient mobile number, UPI ID, or account number."
                            return@Button
                        }
                        pinError = null
                        showPinSheet = true
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(54.dp)
                        .testTag("proceed_to_pay_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple)
                ) {
                    Text(
                        text = if (enteredAmount > 0) "Pay ${PaymentUtils.formatInr(enteredAmount)}" else "Proceed to Pay",
                        style = MaterialTheme.typography.titleMedium
                    )
                }
            }
        }
    }

    if (showPinSheet) {
        val selectedSource = sources.firstOrNull { it.id == selectedSourceId } ?: sources.firstOrNull()
        val amt = amountInput.toDoubleOrNull() ?: 0.0
        val finalTitle = when {
            mode == "SELF" -> "Self Wallet Load"
            recipientName.isNotBlank() -> recipientName.trim()
            else -> recipientTarget.trim()
        }
        val finalSub = when {
            mode == "SELF" -> selectedSource?.label ?: "Bank Account"
            ifscInput.isNotBlank() -> "${recipientTarget.trim()} • $ifscInput"
            else -> recipientTarget.trim()
        }

        UpiPinBottomSheet(
            title = finalTitle,
            subtitle = selectedSource?.label ?: "Mobile pe",
            amountLabel = PaymentUtils.formatInr(amt),
            errorMessage = pinError,
            onDismiss = { showPinSheet = false; pinError = null },
            onPinSubmitted = { pin ->
                if (selectedSource == null) {
                    pinError = "No payment source available"
                    return@UpiPinBottomSheet
                }
                scope.launch {
                    val outcome = if (mode == "SELF" && selectedSource.bankAccountId != null) {
                        viewModel.addMoneyToWallet(selectedSource.bankAccountId, amt, pin)
                    } else {
                        viewModel.executePayment(
                            recipientTitle = finalTitle,
                            recipientSubtitle = finalSub,
                            amount = amt,
                            category = category,
                            source = selectedSource,
                            enteredPin = pin
                        )
                    }
                    when (outcome) {
                        is PaymentOutcome.Success -> {
                            showPinSheet = false
                            pinError = null
                            completedReceipt = outcome.transaction
                        }
                        is PaymentOutcome.InvalidPin -> pinError = outcome.message
                        is PaymentOutcome.InsufficientBalance -> {
                            pinError = "Insufficient balance (${PaymentUtils.formatInr(outcome.available)} available)"
                        }
                        is PaymentOutcome.LimitExceeded -> {
                            showPinSheet = false
                            pinError = null
                            limitWarningDialog = outcome
                        }
                        is PaymentOutcome.Error -> pinError = outcome.message
                    }
                }
            }
        )
    }

    limitWarningDialog?.let { exceeded ->
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { limitWarningDialog = null },
            icon = { Icon(Icons.Default.WarningAmber, contentDescription = null, tint = CrimsonError) },
            title = { Text("Daily Limit Exceeded") },
            text = {
                Text(
                    "Your daily transaction limit on Mobile pe is ${PaymentUtils.formatInr(exceeded.dailyLimit)}. " +
                        "You tried to pay ${PaymentUtils.formatInr(exceeded.requestedAmount)}, " +
                        "but only ${PaymentUtils.formatInr(exceeded.remainingToday)} remains for today."
                )
            },
            confirmButton = {
                Button(
                    onClick = { limitWarningDialog = null },
                    colors = ButtonDefaults.buttonColors(containerColor = PrimaryPurple)
                ) {
                    Text("OK")
                }
            }
        )
    }

    completedReceipt?.let { txn ->
        PaymentReceiptDialog(
            transaction = txn,
            onDismiss = {
                completedReceipt = null
                onBack()
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CheckBalanceScreen(
    viewModel: MobilePeViewModel,
    onBack: () -> Unit
) {
    val user by viewModel.userProfile.collectAsStateWithLifecycle()
    val banks by viewModel.bankAccounts.collectAsStateWithLifecycle()

    var unlockedBankIds by remember { mutableStateOf<Set<Long>>(emptySet()) }
    var pendingBank by remember { mutableStateOf<BankAccountEntity?>(null) }
    var pinError by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Check Bank Balance") },
                navigationIcon = {
                    IconButton(onClick = onBack, modifier = Modifier.minimumInteractiveComponentSize()) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = PrimaryPurple,
                    titleContentColor = Color.White,
                    navigationIconContentColor = Color.White
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Column(
                modifier = Modifier
                    .widthIn(max = 560.dp)
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Card(
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = EmeraldSoft),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = EmeraldSuccess)
                        Spacer(Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text("Mobile pe Wallet", style = MaterialTheme.typography.titleSmall)
                            Text("Instant Balance", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        Text(
                            text = PaymentUtils.formatInr(user?.walletBalance ?: 0.0),
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = EmeraldSuccess
                        )
                    }
                }

                Text(
                    text = "UPI Linked Bank Accounts",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                banks.forEach { bank ->
                    val unlocked = bank.id in unlockedBankIds
                    Card(
                        shape = RoundedCornerShape(18.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(18.dp))
                            .clickable {
                                if (!unlocked) {
                                    pinError = null
                                    pendingBank = bank
                                }
                            }
                            .testTag("check_bank_card_${bank.accountLast4}")
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(46.dp)
                                    .clip(RoundedCornerShape(14.dp))
                                    .background(Color(bank.accentColorHex).copy(alpha = 0.14f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.AccountBalance, contentDescription = null, tint = Color(bank.accentColorHex))
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text("${bank.bankName} ••${bank.accountLast4}", style = MaterialTheme.typography.titleSmall)
                                Text(bank.ifscCode, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            if (unlocked) {
                                Column(horizontalAlignment = Alignment.End) {
                                    Text(
                                        text = PaymentUtils.formatInr(bank.balance),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = EmeraldSuccess
                                    )
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = EmeraldSuccess, modifier = Modifier.size(14.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("Fetched", style = MaterialTheme.typography.labelSmall, color = EmeraldSuccess)
                                    }
                                }
                            } else {
                                Surface(
                                    color = MaterialTheme.colorScheme.primaryContainer,
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text(
                                        text = "Check Balance",
                                        style = MaterialTheme.typography.labelMedium,
                                        color = PrimaryPurple,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    pendingBank?.let { bank ->
        UpiPinBottomSheet(
            title = "Fetch Bank Balance",
            subtitle = "${bank.bankName} ••${bank.accountLast4}",
            errorMessage = pinError,
            onDismiss = { pendingBank = null; pinError = null },
            onPinSubmitted = { pin ->
                if (user?.upiPin == pin) {
                    unlockedBankIds = unlockedBankIds + bank.id
                    pendingBank = null
                    pinError = null
                } else {
                    pinError = "Incorrect 4-digit UPI PIN"
                }
            }
        )
    }
}
