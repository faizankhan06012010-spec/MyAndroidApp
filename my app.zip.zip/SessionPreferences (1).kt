package com.example.data.local

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "mobile_pe_prefs")

class SessionPreferences(private val context: Context) {
    private object Keys {
        val ACTIVE_UID = stringPreferencesKey("active_uid")
        val HIDE_BALANCE = booleanPreferencesKey("hide_balance")
    }

    val activeUid: Flow<String?> = context.dataStore.data.map { it[Keys.ACTIVE_UID] }
    val hideBalance: Flow<Boolean> = context.dataStore.data.map { it[Keys.HIDE_BALANCE] ?: false }

    suspend fun setActiveUid(uid: String?) {
        context.dataStore.edit { prefs ->
            if (uid == null) prefs.remove(Keys.ACTIVE_UID)
            else prefs[Keys.ACTIVE_UID] = uid
        }
    }

    suspend fun setHideBalance(hide: Boolean) {
        context.dataStore.edit { prefs ->
            prefs[Keys.HIDE_BALANCE] = hide
        }
    }
}
