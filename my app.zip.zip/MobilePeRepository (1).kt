package com.example.data.repository

import android.content.Context
import com.example.data.local.MobilePeDao
import com.example.data.local.MobilePeDatabase
import com.example.data.local.SessionPreferences
import com.example.data.model.AppNotificationEntity
import com.example.data.model.BankAccountEntity
import com.example.data.model.PaymentOutcome
import com.example.data.model.PaymentSourceOption
import com.example.data.model.QuickContact
import com.example.data.model.TransactionEntity
import com.example.data.model.UserProfileEntity
import com.example.util.NotificationHelper
import com.example.util.PaymentUtils
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.firstOrNull

class MobilePeRepository(
    private val context: Context,
    private val dao: MobilePeDao,
    private val prefs: SessionPreferences
) {
    constructor(context: Context) : this(
        context = context.applicationContext,
        dao = MobilePeDatabase.getInstance(context).dao(),
        prefs = SessionPreferences(context.applicationContext)
    )

    val activeUid: Flow<String?> = prefs.activeUid
    val hideBalance: Flow<Boolean> = prefs.hideBalance

    fun observeUser(uid: String): Flow<UserProfileEntity?> = dao.observeUser(uid)
    fun observeBankAccounts(userId: String): Flow<List<BankAccountEntity>> = dao.observeBankAccounts(userId)
    fun observeTransactions(userId: String): Flow<List<TransactionEntity>> = dao.observeTransactions(userId)
    fun observeNotifications(userId: String): Flow<List<AppNotificationEntity>> = dao.observeNotifications(userId)
    fun observeUnreadNotificationCount(userId: String): Flow<Int> = dao.observeUnreadNotificationCount(userId)

    suspend fun setHideBalance(hide: Boolean) = prefs.setHideBalance(hide)

    suspend fun checkExistingAadhaar(aadhaarDigits: String): UserProfileEntity? {
        val hash = PaymentUtils.sha256("aadhaar:$aadhaarDigits")
        return dao.getUserByAadhaarHash(hash)
    }

    suspend fun checkExistingMobile(mobileDigits: String): UserProfileEntity? {
        return dao.getUserByMobile(mobileDigits)
    }

    suspend fun loginWithAadhaar(
        aadhaarDigits: String,
        fullName: String,
        mobileDigits: String,
        upiPin: String
    ): Result<UserProfileEntity> {
        if (!PaymentUtils.isValidAadhaarFormat(aadhaarDigits)) {
            return Result.failure(IllegalArgumentException("Enter a valid 12-digit Aadhaar number (cannot start with 0 or 1)."))
        }
        val hash = PaymentUtils.sha256("aadhaar:$aadhaarDigits")
        val existing = dao.getUserByAadhaarHash(hash)
        if (existing != null) {
            if (existing.upiPin != upiPin) {
                return Result.failure(IllegalArgumentException("Incorrect 4-digit Mobile pe PIN for this Aadhaar profile."))
            }
            val refreshed = resetDailyLimitIfNewDay(existing)
            prefs.setActiveUid(refreshed.uid)
            NotificationHelper.showTransactionNotification(
                context,
                "Welcome back to Mobile pe",
                "Signed in securely via Aadhaar (${refreshed.maskedAadhaar}). Daily limit: ₹1,00,000."
            )
            return Result.success(refreshed)
        }

        if (!PaymentUtils.isValidMobile(mobileDigits)) {
            return Result.failure(IllegalArgumentException("Enter a valid 10-digit mobile number linked to Aadhaar."))
        }
        if (fullName.trim().length < 2) {
            return Result.failure(IllegalArgumentException("Enter your full name as on Aadhaar."))
        }
        if (upiPin.length != 4 || !upiPin.all { it.isDigit() }) {
            return Result.failure(IllegalArgumentException("Set a 4-digit numeric UPI PIN."))
        }

        val uid = "usr_${System.currentTimeMillis()}"
        val cleanName = fullName.trim()
        val handle = cleanName.lowercase().replace(Regex("[^a-z0-9]"), "").take(10).ifBlank { "user" }
        val user = UserProfileEntity(
            uid = uid,
            fullName = cleanName,
            mobileNumber = mobileDigits,
            upiId = "${handle}${mobileDigits.takeLast(4)}@mobilepe",
            aadhaarHash = hash,
            maskedAadhaar = PaymentUtils.maskAadhaar(aadhaarDigits),
            aadhaarVerified = true,
            upiPin = upiPin,
            walletBalance = 35000.0,
            dailySpent = 0.0,
            dailyLimitDate = PaymentUtils.todayDateString(),
            city = "Mumbai"
        )
        seedNewUserWorkspace(user)
        prefs.setActiveUid(uid)
        NotificationHelper.showTransactionNotification(
            context,
            "Aadhaar KYC Verified!",
            "Welcome $cleanName. Your Mobile pe account is active with a ₹1,00,000 daily UPI limit."
        )
        return Result.success(user)
    }

    suspend fun loginWithMobile(
        mobileDigits: String,
        fullName: String,
        upiPin: String
    ): Result<UserProfileEntity> {
        if (!PaymentUtils.isValidMobile(mobileDigits)) {
            return Result.failure(IllegalArgumentException("Enter a valid 10-digit Indian mobile number."))
        }
        val existing = dao.getUserByMobile(mobileDigits)
        if (existing != null) {
            if (existing.upiPin != upiPin) {
                return Result.failure(IllegalArgumentException("Incorrect 4-digit Mobile pe PIN."))
            }
            val refreshed = resetDailyLimitIfNewDay(existing)
            prefs.setActiveUid(refreshed.uid)
            NotificationHelper.showTransactionNotification(
                context,
                "Mobile pe Login Alert",
                "Signed in on +91 $mobileDigits. Daily limit remaining: ${PaymentUtils.formatInr(PaymentUtils.DAILY_LIMIT_INR - refreshed.dailySpent)}."
            )
            return Result.success(refreshed)
        }

        if (fullName.trim().length < 2) {
            return Result.failure(IllegalArgumentException("Enter your full name to register."))
        }
        if (upiPin.length != 4 || !upiPin.all { it.isDigit() }) {
            return Result.failure(IllegalArgumentException("Set a 4-digit numeric UPI PIN."))
        }

        val uid = "usr_${System.currentTimeMillis()}"
        val cleanName = fullName.trim()
        val user = UserProfileEntity(
            uid = uid,
            fullName = cleanName,
            mobileNumber = mobileDigits,
            upiId = "${mobileDigits}@mobilepe",
            aadhaarHash = null,
            maskedAadhaar = null,
            aadhaarVerified = false,
            upiPin = upiPin,
            walletBalance = 25000.0,
            dailySpent = 0.0,
            dailyLimitDate = PaymentUtils.todayDateString(),
            city = "Bengaluru"
        )
        seedNewUserWorkspace(user)
        prefs.setActiveUid(uid)
        NotificationHelper.showTransactionNotification(
            context,
            "Welcome to Mobile pe",
            "Account created for +91 $mobileDigits with ₹1,00,000/day transaction limit."
        )
        return Result.success(user)
    }

    suspend fun loginDemoAadhaarAccount(): UserProfileEntity {
        val demoAadhaar = "459812347890"
        val hash = PaymentUtils.sha256("aadhaar:$demoAadhaar")
        val existing = dao.getUserByAadhaarHash(hash)
        if (existing != null) {
            val refreshed = resetDailyLimitIfNewDay(existing)
            prefs.setActiveUid(refreshed.uid)
            return refreshed
        }
        val uid = "usr_demo_aadhaar"
        val user = UserProfileEntity(
            uid = uid,
            fullName = "Aarav Sharma",
            mobileNumber = "9876543210",
            upiId = "aarav.sharma@mobilepe",
            aadhaarHash = hash,
            maskedAadhaar = PaymentUtils.maskAadhaar(demoAadhaar),
            aadhaarVerified = true,
            upiPin = "1234",
            walletBalance = 42500.0,
            dailySpent = 12450.0,
            dailyLimitDate = PaymentUtils.todayDateString(),
            city = "Mumbai"
        )
        seedNewUserWorkspace(user, includeSampleHistory = true)
        prefs.setActiveUid(uid)
        NotificationHelper.showTransactionNotification(
            context,
            "Mobile pe Ready",
            "Signed in as Aarav Sharma (Aadhaar Verified). Daily limit: ₹1,00,000."
        )
        return user
    }

    suspend fun linkAadhaarToCurrentUser(uid: String, aadhaarDigits: String): Result<UserProfileEntity> {
        if (!PaymentUtils.isValidAadhaarFormat(aadhaarDigits)) {
            return Result.failure(IllegalArgumentException("Enter a valid 12-digit Aadhaar number."))
        }
        val user = dao.getUserById(uid) ?: return Result.failure(IllegalStateException("User not found"))
        val updated = user.copy(
            aadhaarHash = PaymentUtils.sha256("aadhaar:$aadhaarDigits"),
            maskedAadhaar = PaymentUtils.maskAadhaar(aadhaarDigits),
            aadhaarVerified = true
        )
        dao.updateUser(updated)
        dao.insertNotification(
            AppNotificationEntity(
                userId = uid,
                title = "Aadhaar KYC Linked",
                message = "Aadhaar ${updated.maskedAadhaar} is now linked for instant biometric & e-KYC login.",
                type = "SECURITY"
            )
        )
        NotificationHelper.showTransactionNotification(
            context,
            "Aadhaar KYC Linked",
            "Aadhaar ${updated.maskedAadhaar} verified on your Mobile pe account."
        )
        return Result.success(updated)
    }

    suspend fun logout() {
        prefs.setActiveUid(null)
    }

    private suspend fun seedNewUserWorkspace(user: UserProfileEntity, includeSampleHistory: Boolean = false) {
        dao.insertUser(user)
        dao.insertBankAccount(
            BankAccountEntity(
                userId = user.uid,
                bankName = "State Bank of India",
                accountLast4 = "4821",
                ifscCode = "SBIN0001245",
                balance = 148500.0,
                isPrimary = true,
                accentColorHex = 0xFF1D4ED8
            )
        )
        dao.insertBankAccount(
            BankAccountEntity(
                userId = user.uid,
                bankName = "HDFC Bank",
                accountLast4 = "9034",
                ifscCode = "HDFC0000812",
                balance = 86200.0,
                isPrimary = false,
                accentColorHex = 0xFF0F766E
            )
        )
        dao.insertBankAccount(
            BankAccountEntity(
                userId = user.uid,
                bankName = "ICICI Bank",
                accountLast4 = "3319",
                ifscCode = "ICIC0000419",
                balance = 54000.0,
                isPrimary = false,
                accentColorHex = 0xFFB45309
            )
        )

        val now = System.currentTimeMillis()
        if (includeSampleHistory) {
            dao.insertTransaction(
                TransactionEntity(
                    userId = user.uid,
                    txnRef = "MP8841209341",
                    utrNumber = "431982019482",
                    title = "Reliance Fresh Mart",
                    subtitle = "reliancefresh@mobilepe",
                    category = "QR_PAY",
                    direction = "DEBIT",
                    amount = 1850.0,
                    status = "SUCCESS",
                    paymentMethod = "SBI ••4821",
                    timestamp = now - 3_600_000L * 2
                )
            )
            dao.insertTransaction(
                TransactionEntity(
                    userId = user.uid,
                    txnRef = "MP8841205510",
                    utrNumber = "431982011209",
                    title = "Priya Sharma",
                    subtitle = "+91 98201 44512",
                    category = "CREDIT",
                    direction = "CREDIT",
                    amount = 4500.0,
                    status = "SUCCESS",
                    paymentMethod = "Mobile pe Wallet",
                    timestamp = now - 3_600_000L * 5
                )
            )
            dao.insertTransaction(
                TransactionEntity(
                    userId = user.uid,
                    txnRef = "MP8841198822",
                    utrNumber = "431981990123",
                    title = "Jio Prepaid Recharge",
                    subtitle = "9876543210 • 28 Days 2GB/day",
                    category = "RECHARGE",
                    direction = "DEBIT",
                    amount = 299.0,
                    status = "SUCCESS",
                    paymentMethod = "Mobile pe Wallet",
                    timestamp = now - 3_600_000L * 8
                )
            )
            dao.insertTransaction(
                TransactionEntity(
                    userId = user.uid,
                    txnRef = "MP8841187410",
                    utrNumber = "431981887321",
                    title = "Adani Electricity Mumbai",
                    subtitle = "Consumer No: 1009482711",
                    category = "BILL_PAY",
                    direction = "DEBIT",
                    amount = 10301.0,
                    status = "SUCCESS",
                    paymentMethod = "SBI ••4821",
                    timestamp = now - 3_600_000L * 11
                )
            )
        }

        dao.insertNotification(
            AppNotificationEntity(
                userId = user.uid,
                title = "Mobile pe ₹1,00,000 Daily Limit Active",
                message = "Send money, scan UPI QRs, or pay bills up to ₹1,00,000 per day with instant alerts.",
                type = "SECURITY",
                timestamp = now
            )
        )
        if (includeSampleHistory) {
            dao.insertNotification(
                AppNotificationEntity(
                    userId = user.uid,
                    title = "Received ₹4,500 from Priya Sharma",
                    message = "Credited to your Mobile pe Wallet via UPI.",
                    type = "PAYMENT_RECEIVED",
                    amount = 4500.0,
                    timestamp = now - 3_600_000L * 5
                )
            )
        }
    }

    private suspend fun resetDailyLimitIfNewDay(user: UserProfileEntity): UserProfileEntity {
        val today = PaymentUtils.todayDateString()
        return if (user.dailyLimitDate != today) {
            val updated = user.copy(dailySpent = 0.0, dailyLimitDate = today)
            dao.updateUser(updated)
            updated
        } else {
            user
        }
    }

    suspend fun getEffectiveDailySpent(uid: String): Double {
        val user = dao.getUserById(uid) ?: return 0.0
        val refreshed = resetDailyLimitIfNewDay(user)
        return refreshed.dailySpent
    }

    suspend fun executePayment(
        uid: String,
        recipientTitle: String,
        recipientSubtitle: String,
        amount: Double,
        category: String,
        source: PaymentSourceOption,
        enteredPin: String
    ): PaymentOutcome {
        if (amount <= 0.0) {
            return PaymentOutcome.Error("Enter an amount greater than ₹0.")
        }
        val rawUser = dao.getUserById(uid) ?: return PaymentOutcome.Error("Session expired. Please sign in again.")
        val user = resetDailyLimitIfNewDay(rawUser)

        if (user.upiPin != enteredPin) {
            return PaymentOutcome.InvalidPin("Incorrect 4-digit UPI PIN. Please try again.")
        }

        // Check ₹1,00,000 daily transaction limit
        val remainingToday = (PaymentUtils.DAILY_LIMIT_INR - user.dailySpent).coerceAtLeast(0.0)
        if (user.dailySpent + amount > PaymentUtils.DAILY_LIMIT_INR) {
            val failedTxn = TransactionEntity(
                userId = uid,
                txnRef = PaymentUtils.generateTxnRef(),
                utrNumber = PaymentUtils.generateUtr(),
                title = recipientTitle,
                subtitle = recipientSubtitle,
                category = category,
                direction = "DEBIT",
                amount = amount,
                status = "FAILED",
                paymentMethod = source.label,
                failureReason = "Daily limit of ₹1,00,000 exceeded. Remaining today: ${PaymentUtils.formatInr(remainingToday)}"
            )
            dao.insertTransaction(failedTxn)
            val alertMsg = "Blocked ${PaymentUtils.formatInr(amount)} payment to $recipientTitle. Daily limit ₹1,00,000 reached (Remaining: ${PaymentUtils.formatInr(remainingToday)})."
            dao.insertNotification(
                AppNotificationEntity(
                    userId = uid,
                    title = "Daily Limit Exceeded (₹1,00,000)",
                    message = alertMsg,
                    type = "LIMIT_ALERT",
                    amount = amount
                )
            )
            NotificationHelper.showTransactionNotification(context, "Daily Limit Alert", alertMsg)
            return PaymentOutcome.LimitExceeded(amount, remainingToday, PaymentUtils.DAILY_LIMIT_INR)
        }

        // Check balance on source
        if (source.isWallet) {
            if (user.walletBalance < amount) {
                return PaymentOutcome.InsufficientBalance(user.walletBalance, amount)
            }
            val updatedUser = user.copy(
                walletBalance = user.walletBalance - amount,
                dailySpent = user.dailySpent + amount,
                dailyLimitDate = PaymentUtils.todayDateString()
            )
            dao.updateUser(updatedUser)
        } else {
            val bankId = source.bankAccountId ?: return PaymentOutcome.Error("Bank account unavailable.")
            val bank = dao.getBankAccountById(bankId) ?: return PaymentOutcome.Error("Bank account not found.")
            if (bank.balance < amount) {
                return PaymentOutcome.InsufficientBalance(bank.balance, amount)
            }
            dao.updateBankAccount(bank.copy(balance = bank.balance - amount))
            dao.updateUser(
                user.copy(
                    dailySpent = user.dailySpent + amount,
                    dailyLimitDate = PaymentUtils.todayDateString()
                )
            )
        }

        val txn = TransactionEntity(
            userId = uid,
            txnRef = PaymentUtils.generateTxnRef(),
            utrNumber = PaymentUtils.generateUtr(),
            title = recipientTitle,
            subtitle = recipientSubtitle,
            category = category,
            direction = "DEBIT",
            amount = amount,
            status = "SUCCESS",
            paymentMethod = source.label
        )
        val insertedId = dao.insertTransaction(txn)
        val savedTxn = txn.copy(id = insertedId)

        val notifType = if (category == "BILL_PAY" || category == "RECHARGE") "BILL_PAID" else "PAYMENT_SENT"
        val newRemaining = (PaymentUtils.DAILY_LIMIT_INR - (user.dailySpent + amount)).coerceAtLeast(0.0)
        val notifTitle = "${PaymentUtils.formatInr(amount)} Paid to $recipientTitle"
        val notifBody = "Paid via ${source.label}. UTR: ${savedTxn.utrNumber}. Daily limit left: ${PaymentUtils.formatInr(newRemaining)}."

        dao.insertNotification(
            AppNotificationEntity(
                userId = uid,
                title = notifTitle,
                message = notifBody,
                type = notifType,
                amount = amount
            )
        )
        NotificationHelper.showTransactionNotification(context, notifTitle, notifBody)
        return PaymentOutcome.Success(savedTxn)
    }

    suspend fun addMoneyToWallet(
        uid: String,
        bankAccountId: Long,
        amount: Double,
        enteredPin: String
    ): PaymentOutcome {
        if (amount <= 0.0) return PaymentOutcome.Error("Enter a valid amount.")
        val user = dao.getUserById(uid) ?: return PaymentOutcome.Error("User not found.")
        if (user.upiPin != enteredPin) return PaymentOutcome.InvalidPin("Incorrect 4-digit UPI PIN.")
        val bank = dao.getBankAccountById(bankId = bankAccountId)
            ?: return PaymentOutcome.Error("Selected bank account not found.")
        if (bank.balance < amount) {
            return PaymentOutcome.InsufficientBalance(bank.balance, amount)
        }

        dao.updateBankAccount(bank.copy(balance = bank.balance - amount))
        dao.updateUser(user.copy(walletBalance = user.walletBalance + amount))

        val txn = TransactionEntity(
            userId = uid,
            txnRef = PaymentUtils.generateTxnRef(),
            utrNumber = PaymentUtils.generateUtr(),
            title = "Added to Mobile pe Wallet",
            subtitle = "From ${bank.bankName} ••${bank.accountLast4}",
            category = "ADD_MONEY",
            direction = "CREDIT",
            amount = amount,
            status = "SUCCESS",
            paymentMethod = "${bank.bankName} ••${bank.accountLast4}"
        )
        val id = dao.insertTransaction(txn)
        val saved = txn.copy(id = id)

        val notifTitle = "${PaymentUtils.formatInr(amount)} Added to Wallet"
        val notifBody = "Transferred from ${bank.bankName} ••${bank.accountLast4} to Mobile pe Wallet."
        dao.insertNotification(
            AppNotificationEntity(
                userId = uid,
                title = notifTitle,
                message = notifBody,
                type = "PAYMENT_RECEIVED",
                amount = amount
            )
        )
        NotificationHelper.showTransactionNotification(context, notifTitle, notifBody)
        return PaymentOutcome.Success(saved)
    }

    suspend fun simulateIncomingCredit(
        uid: String,
        senderName: String,
        senderUpi: String,
        amount: Double
    ): Result<TransactionEntity> {
        val user = dao.getUserById(uid) ?: return Result.failure(IllegalStateException("User not found"))
        dao.updateUser(user.copy(walletBalance = user.walletBalance + amount))
        val txn = TransactionEntity(
            userId = uid,
            txnRef = PaymentUtils.generateTxnRef(),
            utrNumber = PaymentUtils.generateUtr(),
            title = senderName,
            subtitle = senderUpi,
            category = "CREDIT",
            direction = "CREDIT",
            amount = amount,
            status = "SUCCESS",
            paymentMethod = "Mobile pe Wallet"
        )
        val id = dao.insertTransaction(txn)
        val saved = txn.copy(id = id)
        val notifTitle = "Received ${PaymentUtils.formatInr(amount)} from $senderName"
        val notifBody = "Money credited instantly to your Mobile pe Wallet. UTR: ${saved.utrNumber}."
        dao.insertNotification(
            AppNotificationEntity(
                userId = uid,
                title = notifTitle,
                message = notifBody,
                type = "PAYMENT_RECEIVED",
                amount = amount
            )
        )
        NotificationHelper.showTransactionNotification(context, notifTitle, notifBody)
        return Result.success(saved)
    }

    suspend fun addBankAccount(
        uid: String,
        bankName: String,
        accountLast4: String,
        ifscCode: String
    ): Result<Unit> {
        if (bankName.isBlank() || accountLast4.length != 4 || ifscCode.length < 6) {
            return Result.failure(IllegalArgumentException("Enter valid bank details (4-digit account & IFSC)."))
        }
        val colors = listOf(0xFF1D4ED8L, 0xFF0F766EL, 0xFF7C3AEDL, 0xFFB45309L)
        dao.insertBankAccount(
            BankAccountEntity(
                userId = uid,
                bankName = bankName.trim(),
                accountLast4 = accountLast4,
                ifscCode = ifscCode.uppercase().trim(),
                balance = 75000.0,
                isPrimary = false,
                accentColorHex = colors.random()
            )
        )
        dao.insertNotification(
            AppNotificationEntity(
                userId = uid,
                title = "Bank Account Linked",
                message = "${bankName.trim()} ••$accountLast4 linked to Mobile pe UPI.",
                type = "SECURITY"
            )
        )
        return Result.success(Unit)
    }

    suspend fun setPrimaryBank(uid: String, bankId: Long) {
        dao.setPrimaryBankAccount(uid, bankId)
    }

    suspend fun updateUpiPin(uid: String, currentPin: String, newPin: String): Result<Unit> {
        val user = dao.getUserById(uid) ?: return Result.failure(IllegalStateException("User not found"))
        if (user.upiPin != currentPin) return Result.failure(IllegalArgumentException("Current PIN is incorrect."))
        if (newPin.length != 4 || !newPin.all { it.isDigit() }) {
            return Result.failure(IllegalArgumentException("New PIN must be 4 digits."))
        }
        dao.updateUser(user.copy(upiPin = newPin))
        dao.insertNotification(
            AppNotificationEntity(
                userId = uid,
                title = "UPI PIN Updated",
                message = "Your 4-digit Mobile pe UPI PIN was changed successfully.",
                type = "SECURITY"
            )
        )
        return Result.success(Unit)
    }

    suspend fun markAllNotificationsRead(uid: String) {
        dao.markAllNotificationsRead(uid)
    }

    suspend fun markNotificationRead(notificationId: Long) {
        dao.markNotificationRead(notificationId)
    }

    fun getQuickContacts(): List<QuickContact> = listOf(
        QuickContact("Priya Sharma", "9820144512", false, 0xFF7A09EF),
        QuickContact("Rahul Verma", "rahul.v@mobilepe", false, 0xFF0E9F6E),
        QuickContact("Ananya Iyer", "9845011223", false, 0xFF0284C7),
        QuickContact("Chai Point", "chaipoint@mobilepe", true, 0xFFD97706),
        QuickContact("BigBasket", "bigbasket@mobilepe", true, 0xFF15803D),
        QuickContact("Zomato Pay", "zomato@mobilepe", true, 0xFFDC2626)
    )

    suspend fun getPaymentSources(uid: String): List<PaymentSourceOption> {
        val user = dao.getUserById(uid) ?: return emptyList()
        val banks = dao.getBankAccounts(uid)
        val list = mutableListOf(
            PaymentSourceOption(
                id = "WALLET",
                label = "Mobile pe Wallet",
                sublabel = "Instant zero-fee wallet",
                availableBalance = user.walletBalance,
                isWallet = true
            )
        )
        banks.forEach { bank ->
            list.add(
                PaymentSourceOption(
                    id = "BANK_${bank.id}",
                    label = "${bank.bankName} ••${bank.accountLast4}",
                    sublabel = if (bank.isPrimary) "Primary UPI Bank • ${bank.ifscCode}" else bank.ifscCode,
                    availableBalance = bank.balance,
                    isWallet = false,
                    bankAccountId = bank.id
                )
            )
        }
        return list
    }
}
