package com.example.util

import android.graphics.Bitmap
import android.graphics.Color
import android.net.Uri
import com.google.zxing.BarcodeFormat
import com.google.zxing.EncodeHintType
import com.google.zxing.qrcode.QRCodeWriter
import java.security.MessageDigest
import java.text.DecimalFormat
import java.text.DecimalFormatSymbols
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random

object PaymentUtils {
    const val DAILY_LIMIT_INR: Double = 100_000.0
    const val DEMO_OTP: String = "123456"

    fun todayDateString(): String {
        return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
    }

    fun formatInr(amount: Double, showDecimalsIfWhole: Boolean = false): String {
        val absVal = kotlin.math.abs(amount)
        val isWhole = (absVal % 1.0) == 0.0
        val symbols = DecimalFormatSymbols(Locale("en", "IN"))
        val formatter = if (isWhole && !showDecimalsIfWhole) {
            DecimalFormat("##,##,##0", symbols)
        } else {
            DecimalFormat("##,##,##0.00", symbols)
        }
        val sign = if (amount < 0) "-" else ""
        return "${sign}₹${formatter.format(absVal)}"
    }

    fun formatTimestamp(millis: Long): String {
        val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale("en", "IN"))
        return sdf.format(Date(millis))
    }

    fun formatShortTime(millis: Long): String {
        val sdf = SimpleDateFormat("hh:mm a • dd MMM", Locale("en", "IN"))
        return sdf.format(Date(millis))
    }

    fun isValidAadhaarFormat(raw: String): Boolean {
        val digits = raw.filter { it.isDigit() }
        if (digits.length != 12) return false
        if (digits.first() == '0' || digits.first() == '1') return false
        if (digits.toSet().size == 1) return false
        return true
    }

    fun formatAadhaarGrouped(raw: String): String {
        val digits = raw.filter { it.isDigit() }.take(12)
        return digits.chunked(4).joinToString(" ")
    }

    fun maskAadhaar(digits: String): String {
        val clean = digits.filter { it.isDigit() }.takeLast(4).padStart(4, 'X')
        return "XXXX-XXXX-$clean"
    }

    fun isValidMobile(raw: String): Boolean {
        val digits = raw.filter { it.isDigit() }
        return digits.length == 10 && digits.first() in '6'..'9'
    }

    fun sha256(input: String): String {
        val digest = MessageDigest.getInstance("SHA-256").digest(input.toByteArray())
        return digest.joinToString("") { "%02x".format(it) }
    }

    fun generateTxnRef(): String {
        val num = Random.nextLong(1000000000L, 9999999999L)
        return "MP$num"
    }

    fun generateUtr(): String {
        val part1 = Random.nextInt(4000, 9999)
        val part2 = Random.nextLong(10000000L, 99999999L)
        return "$part1$part2"
    }

    data class ParsedUpiQr(
        val upiId: String,
        val payeeName: String,
        val amount: Double? = null,
        val note: String? = null
    )

    fun parseUpiQr(rawValue: String): ParsedUpiQr {
        val trimmed = rawValue.trim()
        if (trimmed.startsWith("upi://pay", ignoreCase = true)) {
            return try {
                val uri = Uri.parse(trimmed)
                val pa = uri.getQueryParameter("pa")?.takeIf { it.isNotBlank() } ?: "merchant@mobilepe"
                val pn = uri.getQueryParameter("pn")?.takeIf { it.isNotBlank() } ?: pa.substringBefore("@")
                val am = uri.getQueryParameter("am")?.toDoubleOrNull()
                val tn = uri.getQueryParameter("tn")
                ParsedUpiQr(upiId = pa, payeeName = pn, amount = am, note = tn)
            } catch (_: Exception) {
                ParsedUpiQr(upiId = "merchant@mobilepe", payeeName = "Verified Merchant")
            }
        }
        if (trimmed.contains("@") && !trimmed.contains(" ")) {
            val name = trimmed.substringBefore("@").replace(".", " ").replaceFirstChar { it.uppercase() }
            return ParsedUpiQr(upiId = trimmed, payeeName = name)
        }
        return ParsedUpiQr(
            upiId = "qrmerchant@mobilepe",
            payeeName = trimmed.take(28).ifBlank { "QR Merchant" }
        )
    }

    fun generateQrBitmap(content: String, sizePx: Int = 512): Bitmap? {
        return try {
            val hints = mapOf(
                EncodeHintType.MARGIN to 1
            )
            val bitMatrix = QRCodeWriter().encode(content, BarcodeFormat.QR_CODE, sizePx, sizePx, hints)
            val width = bitMatrix.width
            val height = bitMatrix.height
            val pixels = IntArray(width * height)
            for (y in 0 until height) {
                val offset = y * width
                for (x in 0 until width) {
                    pixels[offset + x] = if (bitMatrix[x, y]) Color.parseColor("#1A1426") else Color.WHITE
                }
            }
            Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888).apply {
                setPixels(pixels, 0, width, 0, 0, width, height)
            }
        } catch (_: Exception) {
            null
        }
    }
}
