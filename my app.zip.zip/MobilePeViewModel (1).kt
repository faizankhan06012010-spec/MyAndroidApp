package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppNotificationEntity
import com.example.data.model.BankAccountEntity
import com.example.data.model.PaymentOutcome
import com.example.data.model.PaymentSourceOption
import com.example.data.model.QuickContact
import com.example.data.model.TransactionEntity
import com.example.data.model.UserProfileEntity
import com.example.data.repository.MobilePeRepository
import com.example.util.PaymentUtils
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

sealed interface AuthSessionState {
    data object Loading : AuthSessionState
    data object Unauthenticated : AuthSessionState
    data class Authenticated(val uid: String) : AuthSessionState
}

@OptIn(ExperimentalCoroutinesApi::class)
class MobilePeViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = MobilePeRepository(application.applicationContext)

    val authState: StateFlow<AuthSessionState> = repository.activeUid
        .map { uid ->
            if (uid.isNullOrBlank()) AuthSessionState.Unauthenticated
            else AuthSessionState.Authenticated(uid)
        }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = AuthSessionState.Loading
        )

    val hideBalance: StateFlow<Boolean> = repository.hideBalance
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), false)

    val userProfile: StateFlow<UserProfileEntity?> = repository.activeUid
        .flatMapLatest { uid ->
            if (uid.isNullOrBlank()) flowOf(null) else repository.observeUser(uid)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)

    val bankAccounts: StateFlow<List<BankAccountEntity>> = repository.activeUid
        .flatMapLatest { uid ->
            if (uid.isNullOrBlank()) flowOf(emptyList()) else repository.observeBankAccounts(uid)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val transactions: StateFlow<List<TransactionEntity>> = repository.activeUid
        .flatMapLatest { uid ->
            if (uid.isNullOrBlank()) flowOf(emptyList()) else repository.observeTransactions(uid)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val notifications: StateFlow<List<AppNotificationEntity>> = repository.activeUid
        .flatMapLatest { uid ->
            if (uid.isNullOrBlank()) flowOf(emptyList()) else repository.observeNotifications(uid)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val unreadNotificationCount: StateFlow<Int> = repository.activeUid
        .flatMapLatest { uid ->
            if (uid.isNullOrBlank()) flowOf(0) else repository.observeUnreadNotificationCount(uid)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    val paymentSources: StateFlow<List<PaymentSourceOption>> = combine(userProfile, bankAccounts) { user, banks ->
        if (user == null) {
            emptyList()
        } else {
            val list = mutableListOf(
                PaymentSourceOption(
                    id = "WALLET",
                    label = "Mobile pe Wallet",
                    sublabel = "Instant UPI Wallet",
                    availableBalance = user.walletBalance,
                    isWallet = true
                )
            )
            banks.forEach { bank ->
                list.add(
                    PaymentSourceOption(
                        id = "BANK_${bank.id}",
                        label = "${bank.bankName} ••${bank.accountLast4}",
                        sublabel = if (bank.isPrimary) "Primary UPI Bank • ${bank.ifscCode}" else bank.ifscCode,
                        availableBalance = bank.balance,
                        isWallet = false,
                        bankAccountId = bank.id
                    )
                )
            }
            list
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val quickContacts: List<QuickContact> = repository.getQuickContacts()

    private val _statusBanner = MutableStateFlow<String?>(null)
    val statusBanner: StateFlow<String?> = _statusBanner.asStateFlow()

    fun clearStatusBanner() {
        _statusBanner.value = null
    }

    fun effectiveDailySpent(user: UserProfileEntity?): Double {
        if (user == null) return 0.0
        return if (user.dailyLimitDate == PaymentUtils.todayDateString()) user.dailySpent else 0.0
    }

    fun remainingDailyLimit(user: UserProfileEntity?): Double {
        return (PaymentUtils.DAILY_LIMIT_INR - effectiveDailySpent(user)).coerceAtLeast(0.0)
    }

    fun toggleHideBalance() {
        viewModelScope.launch {
            repository.setHideBalance(!hideBalance.value)
        }
    }

    suspend fun checkExistingAadhaar(aadhaarDigits: String): UserProfileEntity? {
        return repository.checkExistingAadhaar(aadhaarDigits)
    }

    suspend fun checkExistingMobile(mobileDigits: String): UserProfileEntity? {
        return repository.checkExistingMobile(mobileDigits)
    }

    suspend fun loginWithAadhaar(
        aadhaarDigits: String,
        fullName: String,
        mobileDigits: String,
        upiPin: String
    ): Result<UserProfileEntity> {
        return repository.loginWithAadhaar(aadhaarDigits, fullName, mobileDigits, upiPin)
    }

    suspend fun loginWithMobile(
        mobileDigits: String,
        fullName: String,
        upiPin: String
    ): Result<UserProfileEntity> {
        return repository.loginWithMobile(mobileDigits, fullName, upiPin)
    }

    fun loginDemoAadhaar() {
        viewModelScope.launch {
            repository.loginDemoAadhaarAccount()
        }
    }

    suspend fun executePayment(
        recipientTitle: String,
        recipientSubtitle: String,
        amount: Double,
        category: String,
        source: PaymentSourceOption,
        enteredPin: String
    ): PaymentOutcome {
        val uid = userProfile.value?.uid
            ?: return PaymentOutcome.Error("Not signed in")
        return repository.executePayment(
            uid = uid,
            recipientTitle = recipientTitle,
            recipientSubtitle = recipientSubtitle,
            amount = amount,
            category = category,
            source = source,
            enteredPin = enteredPin
        )
    }

    suspend fun addMoneyToWallet(
        bankAccountId: Long,
        amount: Double,
        enteredPin: String
    ): PaymentOutcome {
        val uid = userProfile.value?.uid
            ?: return PaymentOutcome.Error("Not signed in")
        return repository.addMoneyToWallet(uid, bankAccountId, amount, enteredPin)
    }

    fun simulateIncomingCredit(senderName: String = "Vikram Mehta", amount: Double = 500.0) {
        val uid = userProfile.value?.uid ?: return
        viewModelScope.launch {
            repository.simulateIncomingCredit(uid, senderName, "vikram.m@mobilepe", amount)
            _statusBanner.value = "Received ${PaymentUtils.formatInr(amount)} from $senderName"
        }
    }

    suspend fun linkAadhaar(aadhaarDigits: String): Result<UserProfileEntity> {
        val uid = userProfile.value?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        return repository.linkAadhaarToCurrentUser(uid, aadhaarDigits)
    }

    suspend fun addBankAccount(bankName: String, accountLast4: String, ifscCode: String): Result<Unit> {
        val uid = userProfile.value?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        return repository.addBankAccount(uid, bankName, accountLast4, ifscCode)
    }

    fun setPrimaryBank(bankId: Long) {
        val uid = userProfile.value?.uid ?: return
        viewModelScope.launch {
            repository.setPrimaryBank(uid, bankId)
            _statusBanner.value = "Primary UPI bank updated"
        }
    }

    suspend fun updateUpiPin(currentPin: String, newPin: String): Result<Unit> {
        val uid = userProfile.value?.uid ?: return Result.failure(IllegalStateException("Not signed in"))
        return repository.updateUpiPin(uid, currentPin, newPin)
    }

    fun markAllNotificationsRead() {
        val uid = userProfile.value?.uid ?: return
        viewModelScope.launch {
            repository.markAllNotificationsRead(uid)
        }
    }

    fun markNotificationRead(id: Long) {
        viewModelScope.launch {
            repository.markNotificationRead(id)
        }
    }

    fun logout() {
        viewModelScope.launch {
            repository.logout()
        }
    }
}
